from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .common import load_frame, project_paths, sha256_file


REQUIRED_PROCESSED = [
    "market_panel",
    "financial_panel",
    "factor_panel_2025",
    "selected_portfolios_2025",
    "backtest_2025_timeseries",
    "backtest_2025_metrics",
    "backtest_2025_rebalances",
]


def detect_provenance(root: str | Path | None = None) -> dict[str, Any]:
    paths = project_paths(root)
    raw_dir = paths.raw / "snapshot_2025"
    manifest_path = raw_dir / "manifest.json"
    fixture_marker = raw_dir / "README.txt"

    if manifest_path.exists():
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        provider = str(payload.get("metadata", {}).get("provider", ""))
        if "Tushare" in provider:
            return {
                "kind": "real_tushare",
                "classroom_eligible": True,
                "manifest": str(manifest_path),
                "message": "Real Tushare snapshot manifest detected.",
            }

    if fixture_marker.exists() or (raw_dir / "daily.csv").exists() and not manifest_path.exists():
        return {
            "kind": "fixture_or_unverified",
            "classroom_eligible": False,
            "manifest": None,
            "message": "Fixture or unverified raw data detected. Do not present as real 2025 evidence.",
        }

    return {
        "kind": "missing",
        "classroom_eligible": False,
        "manifest": None,
        "message": "No raw snapshot detected.",
    }


def validate_processed_outputs(root: str | Path | None = None) -> list[str]:
    paths = project_paths(root)
    issues: list[str] = []
    for stem in REQUIRED_PROCESSED:
        try:
            frame = load_frame(paths.processed / stem)
        except FileNotFoundError:
            issues.append(f"Missing processed output: {stem}")
            continue
        if frame.empty:
            issues.append(f"Processed output is empty: {stem}")
    return issues


def _copy_if_exists(src: Path, dst: Path) -> None:
    if src.is_dir():
        shutil.copytree(src, dst, dirs_exist_ok=True)
    elif src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def prepare_classroom_cache(
    root: str | Path | None = None,
    *,
    include_raw: bool = False,
    allow_fixture: bool = False,
    cache_id: str | None = None,
) -> Path:
    paths = project_paths(root)
    provenance = detect_provenance(paths.root)
    if not provenance["classroom_eligible"] and not allow_fixture:
        raise RuntimeError(
            "A real Tushare snapshot was not detected. Run the real download first, or pass "
            "allow_fixture=True only for software testing."
        )

    issues = validate_processed_outputs(paths.root)
    if issues:
        raise RuntimeError("Cannot prepare classroom cache:\n- " + "\n- ".join(issues))

    cache_id = cache_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    cache_root = paths.root / "classroom_cache"
    snapshot = cache_root / "snapshots" / cache_id
    if snapshot.exists():
        shutil.rmtree(snapshot)
    snapshot.mkdir(parents=True, exist_ok=True)

    _copy_if_exists(paths.processed, snapshot / "processed")
    _copy_if_exists(paths.root / "prompts", snapshot / "prompts")
    _copy_if_exists(paths.root / "config" / "course_config.yaml", snapshot / "course_config.yaml")
    _copy_if_exists(paths.root / "data" / "00_universe_ashare_2025.csv", snapshot / "universe.csv")
    if include_raw:
        _copy_if_exists(paths.raw / "snapshot_2025", snapshot / "raw_snapshot_2025")

    metadata = {
        "cache_id": cache_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "provenance": provenance,
        "include_raw": include_raw,
        "warning": (
            "REAL TUSHARE DERIVED CACHE" if provenance["classroom_eligible"] else
            "SYNTHETIC FIXTURE CACHE - NOT REAL MARKET EVIDENCE"
        ),
    }
    (snapshot / "CACHE_METADATA.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    files = []
    for path in sorted(snapshot.rglob("*")):
        if path.is_file() and path.name != "CACHE_MANIFEST.json":
            files.append({
                "path": str(path.relative_to(snapshot)),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    manifest = {**metadata, "files": files}
    (snapshot / "CACHE_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (cache_root / "latest.json").write_text(
        json.dumps({"cache_id": cache_id}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return snapshot



def refresh_cache_manifest(cache_path: Path) -> Path:
    metadata_path = cache_path / "CACHE_METADATA.json"
    if not metadata_path.exists():
        raise FileNotFoundError(metadata_path)
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    files = []
    for path in sorted(cache_path.rglob("*")):
        if path.is_file() and path.name != "CACHE_MANIFEST.json":
            files.append({
                "path": str(path.relative_to(cache_path)),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    payload = {**metadata, "files": files}
    out = cache_path / "CACHE_MANIFEST.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def resolve_cache(root: str | Path | None = None, cache_id: str | None = None) -> Path | None:
    paths = project_paths(root)
    cache_root = paths.root / "classroom_cache"
    if cache_id:
        candidate = cache_root / "snapshots" / cache_id
        return candidate if candidate.exists() else None
    latest = cache_root / "latest.json"
    if not latest.exists():
        return None
    payload = json.loads(latest.read_text(encoding="utf-8"))
    candidate = cache_root / "snapshots" / payload["cache_id"]
    return candidate if candidate.exists() else None


def verify_cache(cache_path: Path) -> list[str]:
    issues: list[str] = []
    manifest_path = cache_path / "CACHE_MANIFEST.json"
    if not manifest_path.exists():
        return ["CACHE_MANIFEST.json is missing"]
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    for item in payload.get("files", []):
        path = cache_path / item["path"]
        if not path.exists():
            issues.append(f"Missing cache file: {item['path']}")
            continue
        if path.stat().st_size != item["bytes"]:
            issues.append(f"Size mismatch: {item['path']}")
        if sha256_file(path) != item["sha256"]:
            issues.append(f"Checksum mismatch: {item['path']}")
    return issues


def _cli() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Classroom cache manager")
    sub = parser.add_subparsers(dest="command", required=True)

    create = sub.add_parser("create", help="Create a portable classroom cache")
    create.add_argument("--cache-id", default=None)
    create.add_argument("--include-raw", action="store_true")
    create.add_argument("--allow-fixture", action="store_true")

    verify = sub.add_parser("verify", help="Verify cache files and SHA-256 checksums")
    verify.add_argument("--cache-id", default=None)

    sub.add_parser("list", help="List available cache snapshots")
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    if args.command == "create":
        path = prepare_classroom_cache(
            root, include_raw=args.include_raw, allow_fixture=args.allow_fixture, cache_id=args.cache_id
        )
        print(path)
        return 0
    if args.command == "verify":
        path = resolve_cache(root, args.cache_id)
        if path is None:
            print("Cache not found")
            return 2
        issues = verify_cache(path)
        if issues:
            print("\n".join(f"FAIL: {item}" for item in issues))
            return 2
        print(f"PASS: {path}")
        return 0
    cache_root = root / "classroom_cache" / "snapshots"
    for path in sorted(cache_root.glob("*")) if cache_root.exists() else []:
        if path.is_dir():
            print(path.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
