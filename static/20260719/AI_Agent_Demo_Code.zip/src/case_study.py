from __future__ import annotations

from pathlib import Path

import pandas as pd

from .common import load_config, load_frame, project_paths, save_frame


def build_moutai_wuliangye_case(root: str | Path | None = None) -> tuple[pd.DataFrame, Path]:
    paths = project_paths(root)
    cfg = load_config(root)
    case_date = pd.Timestamp(cfg["calendar"]["factor_snapshot_date"])
    tickers = ["600519.SH", "000858.SZ"]

    factor_panel = load_frame(paths.processed / "factor_panel_2025")
    market = load_frame(paths.processed / "market_panel")
    financials = load_frame(paths.processed / "financial_panel")

    factor_panel["signal_date"] = pd.to_datetime(factor_panel["signal_date"])
    market["trade_date"] = pd.to_datetime(market["trade_date"])
    financials["ann_date"] = pd.to_datetime(financials["ann_date"])
    financials["end_date"] = pd.to_datetime(financials["end_date"])

    available_signals = factor_panel.loc[factor_panel["signal_date"] <= case_date, "signal_date"]
    signal_date = available_signals.max()
    factors = factor_panel[(factor_panel["signal_date"] == signal_date) & factor_panel["ts_code"].isin(tickers)].copy()

    records = []
    for ticker in tickers:
        known = financials[(financials["ts_code"] == ticker) & (financials["ann_date"] <= case_date)]
        latest_fin = known.sort_values(["end_date", "ann_date"]).tail(1)
        prices = market[(market["ts_code"] == ticker) & (market["trade_date"] <= case_date)].sort_values("trade_date")
        ytd = prices[prices["trade_date"] >= pd.Timestamp("2025-01-01")]
        ytd_return = ytd["adj_close_return_equivalent"].iloc[-1] / ytd["adj_close_return_equivalent"].iloc[0] - 1 if len(ytd) > 1 else float("nan")
        row = factors[factors["ts_code"] == ticker].iloc[0].to_dict() if not factors[factors["ts_code"] == ticker].empty else {"ts_code": ticker}
        row["ytd_return_to_case_date"] = ytd_return
        if not latest_fin.empty:
            for col in ["ann_date", "end_date", "roe", "roe_dt", "ocf_to_or", "debt_to_assets", "netprofit_margin", "grossprofit_margin", "tr_yoy", "or_yoy", "netprofit_yoy", "dt_netprofit_yoy", "ocf_yoy"]:
                if col in latest_fin.columns:
                    row[f"latest_{col}"] = latest_fin.iloc[0][col]
        records.append(row)

    case = pd.DataFrame(records)
    out_base = paths.processed / "case_moutai_vs_wuliangye_2025"
    save_frame(case, out_base)

    lines = [
        "# 贵州茅台 vs 五粮液：2025 历史数据对比案例证据包",
        "",
        f"- 数据提供商：Tushare Pro",
        f"- 截止日期：{case_date.date()}",
        f"- 因子信号日期：{signal_date.date()}",
        "- 所有财务字段仅使用 ann_date 不晚于截止日期的记录。",
        "- 本文件是课堂研究输入，不是投资建议。",
        "",
    ]
    for _, row in case.iterrows():
        lines.extend(
            [
                f"## {row.get('name', row['ts_code'])}（{row['ts_code']}）",
                f"- 行业：{row.get('industry_group', '')}",
                f"- 2025年至截止日复权收益：{row.get('ytd_return_to_case_date', float('nan')):.2%}",
                f"- PE TTM：{row.get('pe_ttm', float('nan')):.2f}",
                f"- PB：{row.get('pb', float('nan')):.2f}",
                f"- 最新已知 ROE（扣非优先）：{row.get('quality_roe', float('nan')):.2f}",
                f"- 经营现金流／营业收入：{row.get('ocf_to_or', float('nan')):.2f}",
                f"- 资产负债率：{row.get('debt_to_assets', float('nan')):.2f}",
                f"- 成长分数：{row.get('growth_score', float('nan')):.3f}",
                f"- 营收同比：{row.get('revenue_growth_yoy', float('nan')):.2f}%",
                f"- 扣非/净利润同比：{row.get('profit_growth_yoy', float('nan')):.2f}%",
                f"- 经营现金流同比：{row.get('ocf_growth_yoy', float('nan')):.2f}%",
                f"- 综合因子分数：{row.get('composite_score', float('nan')):.3f}",
                f"- 横截面排名：{row.get('rank', float('nan'))}",
                "",
            ]
        )
    lines.extend(
        [
            "## 课堂讨论问题",
            "1. 估值差异是否有盈利质量、增长或风险证据支持？",
            "2. 2025 年价格表现是否与基本面方向一致？",
            "3. 哪些结论只是横截面比较，不能推导成买卖建议？",
            "4. 还缺少哪些公告、渠道、竞争和现金流细节？",
        ]
    )
    md_path = paths.processed / "case_moutai_vs_wuliangye_2025_evidence.md"
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return case, md_path
