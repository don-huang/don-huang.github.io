from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from dotenv import load_dotenv
from openai import OpenAI


@dataclass(frozen=True)
class LLMSettings:
    api_key: str
    base_url: str
    model: str
    temperature: float = 0.1
    max_tokens: int = 3500

    @property
    def configured(self) -> bool:
        return bool(self.api_key and self.base_url and self.model)


def load_llm_settings(root: str | Path | None = None) -> LLMSettings:
    base = Path(root or Path(__file__).resolve().parents[1]).resolve()
    load_dotenv(base / ".env", override=False)
    api_key = (
        os.getenv("LLM_API_KEY", "").strip()
        or os.getenv("DEEPSEEK_API_KEY", "").strip()
        or os.getenv("DASHSCOPE_API_KEY", "").strip()
        or os.getenv("ZHIPU_API_KEY", "").strip()
        or os.getenv("MINIMAX_API_KEY", "").strip()
    )
    return LLMSettings(
        api_key=api_key,
        base_url=os.getenv("LLM_BASE_URL", "https://api.deepseek.com").strip(),
        model=os.getenv("LLM_MODEL", "deepseek-v4-flash").strip(),
        temperature=float(os.getenv("LLM_TEMPERATURE", "0.1")),
        max_tokens=int(os.getenv("LLM_MAX_TOKENS", "3500")),
    )


class OpenAICompatibleClient:
    def __init__(self, settings: LLMSettings):
        if not settings.configured:
            raise RuntimeError(
                "LLM is not configured. Set LLM_API_KEY, LLM_BASE_URL and LLM_MODEL in .env."
            )
        self.settings = settings
        self.client = OpenAI(api_key=settings.api_key, base_url=settings.base_url)

    def chat(self, messages: Iterable[dict[str, str]], *, max_tokens: int | None = None) -> str:
        response = self.client.chat.completions.create(
            model=self.settings.model,
            messages=list(messages),
            temperature=self.settings.temperature,
            max_tokens=max_tokens or self.settings.max_tokens,
            stream=False,
        )
        choice = response.choices[0]
        content = choice.message.content or ""
        if not content.strip():
            reasoning = getattr(choice.message, "reasoning_content", "")
            raise RuntimeError(
                "LLM returned an empty final answer. "
                f"finish_reason={choice.finish_reason!r}; "
                f"reasoning_present={bool(reasoning)}"
            )
        return content.strip()

    def smoke_test(self) -> str:
        return self.chat(
            [
                {"role": "system", "content": "只回答 OK。"},
                {"role": "user", "content": "连接测试"},
            ],
            max_tokens=128,
        ).strip()
