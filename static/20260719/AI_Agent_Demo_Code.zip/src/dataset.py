from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

from .common import load_config, load_frame, project_paths, save_frame

LOGGER = logging.getLogger(__name__)

DATE_COLUMNS = {
    "daily": ["trade_date"],
    "adj_factor": ["trade_date"],
    "daily_basic": ["trade_date"],
    "fina_indicator": ["ann_date", "end_date"],
    "stock_basic": ["list_date", "delist_date"],
    "trade_cal": ["cal_date", "pretrade_date"],
    "index_daily": ["trade_date"],
}


def _parse_yyyymmdd(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series.astype("string"), format="%Y%m%d", errors="coerce")


def load_raw_endpoint(root: str | Path | None, endpoint: str) -> pd.DataFrame:
    paths = project_paths(root)
    df = load_frame(paths.raw / "snapshot_2025" / endpoint)
    for col in DATE_COLUMNS.get(endpoint, []):
        if col in df.columns:
            df[col] = _parse_yyyymmdd(df[col])
    return df


def build_processed_dataset(root: str | Path | None = None) -> dict[str, Path]:
    paths = project_paths(root)
    cfg = load_config(root)
    universe = pd.read_csv(paths.root / cfg["universe"]["file"], dtype=str)

    daily = load_raw_endpoint(root, "daily")
    adj = load_raw_endpoint(root, "adj_factor")
    daily_basic = load_raw_endpoint(root, "daily_basic")
    financials = load_raw_endpoint(root, "fina_indicator")
    stock_basic = load_raw_endpoint(root, "stock_basic")
    trade_cal = load_raw_endpoint(root, "trade_cal")
    benchmark = load_raw_endpoint(root, "index_daily")

    for name, df in {
        "daily": daily,
        "adj_factor": adj,
        "daily_basic": daily_basic,
        "fina_indicator": financials,
    }.items():
        if df.empty:
            raise RuntimeError(f"Raw endpoint {name} is empty. Run the Tushare download step first.")

    market = daily.merge(adj, on=["ts_code", "trade_date"], how="left", validate="one_to_one")
    market = market.merge(
        daily_basic,
        on=["ts_code", "trade_date"],
        how="left",
        suffixes=("", "_basic"),
        validate="one_to_one",
    )
    market["adj_factor"] = market.groupby("ts_code")["adj_factor"].ffill().bfill()
    # close * adj_factor is proportional to a forward-adjusted price series and is sufficient for returns.
    market["adj_close_return_equivalent"] = market["close"] * market["adj_factor"]
    market = market.merge(
        universe[["ts_code", "name", "industry_group", "teaching_role"]],
        on="ts_code",
        how="inner",
        validate="many_to_one",
    )
    market = market.sort_values(["trade_date", "ts_code"]).reset_index(drop=True)

    stock_columns = [
        col
        for col in ["ts_code", "name", "industry", "market", "exchange", "list_status", "list_date", "delist_date"]
        if col in stock_basic.columns
    ]
    stock_master = universe.merge(stock_basic[stock_columns], on="ts_code", how="left", suffixes=("_course", "_tushare"))
    if "name_tushare" in stock_master.columns:
        stock_master["name"] = stock_master["name_tushare"].fillna(stock_master["name_course"])
    else:
        stock_master["name"] = stock_master["name_course"]

    financials = financials.sort_values(["ts_code", "ann_date", "end_date"]).drop_duplicates(
        ["ts_code", "ann_date", "end_date"], keep="last"
    )
    benchmark = benchmark.sort_values("trade_date").drop_duplicates("trade_date", keep="last")
    if not benchmark.empty:
        benchmark["benchmark_return"] = benchmark["close"].pct_change()

    output_paths = {
        "market_panel": paths.processed / "market_panel",
        "financial_panel": paths.processed / "financial_panel",
        "stock_master": paths.processed / "stock_master",
        "trade_calendar": paths.processed / "trade_calendar",
        "benchmark": paths.processed / "benchmark_hs300",
    }
    save_frame(market, output_paths["market_panel"])
    save_frame(financials, output_paths["financial_panel"])
    save_frame(stock_master, output_paths["stock_master"])
    save_frame(trade_cal, output_paths["trade_calendar"])
    save_frame(benchmark, output_paths["benchmark"])

    LOGGER.info("Processed market rows: %d", len(market))
    LOGGER.info("Processed financial rows: %d", len(financials))
    return output_paths
