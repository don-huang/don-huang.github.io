"""Tushare A-share 2025 teaching pipeline."""
