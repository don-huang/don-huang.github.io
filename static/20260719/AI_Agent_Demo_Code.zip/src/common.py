from __future__ import annotations

import hashlib
import json
import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml
from dotenv import load_dotenv


@dataclass(frozen=True)
class ProjectPaths:
    root: Path
    config: Path
    raw: Path
    processed: Path
    logs: Path


def project_paths(root: str | Path | None = None) -> ProjectPaths:
    base = Path(root or Path(__file__).resolve().parents[1]).resolve()
    return ProjectPaths(
        root=base,
        config=base / "config" / "course_config.yaml",
        raw=base / "data" / "raw" / "tushare",
        processed=base / "data" / "processed",
        logs=base / "logs",
    )


def load_config(root: str | Path | None = None) -> dict[str, Any]:
    paths = project_paths(root)
    with paths.config.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return cfg


def load_environment(root: str | Path | None = None) -> None:
    paths = project_paths(root)
    load_dotenv(paths.root / ".env", override=False)


def setup_logging(root: str | Path | None = None, level: int = logging.INFO) -> None:
    paths = project_paths(root)
    paths.logs.mkdir(parents=True, exist_ok=True)
    log_file = paths.logs / "pipeline.log"
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler(), logging.FileHandler(log_file, encoding="utf-8")],
        force=True,
    )


def require_token(root: str | Path | None = None) -> str:
    load_environment(root)
    token = os.getenv("TUSHARE_TOKEN", "").strip()
    if not token or token == "replace_with_your_tushare_pro_token":
        raise RuntimeError(
            "TUSHARE_TOKEN is missing. Copy .env.example to .env, paste your Tushare Pro token, "
            "and keep .env out of Git."
        )
    return token


def save_frame(df: pd.DataFrame, base_path: Path, *, csv: bool = True, parquet: bool = True) -> None:
    base_path.parent.mkdir(parents=True, exist_ok=True)
    if csv:
        df.to_csv(base_path.with_suffix(".csv"), index=False, encoding="utf-8-sig")
    if parquet:
        try:
            df.to_parquet(base_path.with_suffix(".parquet"), index=False)
        except ImportError:
            logging.getLogger(__name__).warning("Parquet engine unavailable; CSV was still saved for %s", base_path)


def load_frame(base_path: Path) -> pd.DataFrame:
    parquet_path = base_path.with_suffix(".parquet")
    csv_path = base_path.with_suffix(".csv")
    if parquet_path.exists():
        return pd.read_parquet(parquet_path)
    if csv_path.exists():
        return pd.read_csv(csv_path)
    raise FileNotFoundError(f"Neither {parquet_path} nor {csv_path} exists")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_manifest(directory: Path, metadata: dict[str, Any] | None = None) -> Path:
    files = []
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            files.append(
                {
                    "path": str(path.relative_to(directory)),
                    "bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                }
            )
    payload = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "metadata": metadata or {},
        "files": files,
    }
    out = directory / "manifest.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
