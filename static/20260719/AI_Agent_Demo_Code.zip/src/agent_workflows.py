from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import pandas as pd

from .cache_manager import resolve_cache
from .llm_client import OpenAICompatibleClient, load_llm_settings
from .common import project_paths


@dataclass(frozen=True)
class AgentResult:
    workflow: str
    content: str
    mode: str
    source_files: list[str]


def _read_text(path: Path, max_chars: int = 60000) -> str:
    if not path.exists():
        return f"[MISSING FILE: {path}]"
    text = path.read_text(encoding="utf-8", errors="replace")
    if len(text) > max_chars:
        return text[:max_chars] + "\n[TRUNCATED]"
    return text


def _data_base(root: Path) -> tuple[Path, str]:
    cache_id = os.getenv("CLASSROOM_CACHE_ID", "").strip() or None
    cache = resolve_cache(root, cache_id)
    if cache and (cache / "processed").exists():
        metadata_path = cache / "CACHE_METADATA.json"
        source_mode = "classroom_cache"
        if metadata_path.exists():
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
                provenance = metadata.get("provenance", {})
                provenance_kind = (
                    provenance.get("kind", "")
                    if isinstance(provenance, dict)
                    else str(provenance)
                ).lower()
                warning = str(metadata.get("warning", "")).lower()
                if "fixture" in provenance_kind or "synthetic" in warning:
                    source_mode = "fixture"
            except (OSError, ValueError, TypeError):
                source_mode = "classroom_cache"
        return cache / "processed", source_mode
    processed = root / "data" / "processed"
    if (processed / "agent_inputs").exists():
        return processed, "processed"
    fixture = root / "data" / "fixtures" / "expected_pipeline_outputs"
    return fixture, "fixture"


def available_inputs(root: str | Path | None = None) -> dict[str, Path]:
    paths = project_paths(root)
    base, _ = _data_base(paths.root)
    agent_dir = base / "agent_inputs"
    return {
        "factor": agent_dir / "factor_snapshot_latest.csv",
        "backtest_metrics": agent_dir / "backtest_metrics.csv",
        "rebalance_log": agent_dir / "rebalance_log.csv",
        "backtest_last_30_days": agent_dir / "backtest_last_30_days.csv",
        "strategy_spec": agent_dir / "strategy_spec.md",
        "strategy_summary": agent_dir / "strategy_agent_summary.json",
        "data_quality_summary": agent_dir / "data_quality_summary.json",
        "premarket_market": base / "premarket_20251103_market.csv",
        "premarket_portfolio": base / "premarket_20251103_portfolio.csv",
        "trade_log": base / "simulated_trade_log_2025.csv",
        "committee_case": base / "case_moutai_vs_wuliangye_2025.csv",
        "committee_evidence": base / "case_moutai_vs_wuliangye_2025_evidence.md",
    }


def _offline_report(root: Path, workflow: str, files: Mapping[str, Path], source_mode: str) -> str:
    warning = (
        "真实/已冻结数据" if source_mode in {"classroom_cache", "processed"}
        else "合成 fixture（仅软件测试，不是真实2025市场证据）"
    )
    lines = [
        f"# {workflow} - 离线确定性摘要",
        "",
        f"数据模式：{warning}",
        "",
        "当前未调用大模型。以下内容只确认文件存在与确定性程序输出，不提供投资结论。",
        "",
        "## 输入文件",
    ]
    for name, path in files.items():
        lines.append(f"- {name}: {path.name} ({'存在' if path.exists() else '缺失'})")

    if workflow == "Factor Agent" and files.get("factor", Path()).exists():
        df = pd.read_csv(files["factor"])
        lines += [
            "",
            "## 确定性统计",
            f"- 行数：{len(df)}",
            f"- Eligible：{int(df.get('eligible', pd.Series(dtype=bool)).fillna(False).astype(bool).sum()) if 'eligible' in df else 'N/A'}",
            f"- Selected：{int(df.get('selected', pd.Series(dtype=bool)).fillna(False).astype(bool).sum()) if 'selected' in df else 'N/A'}",
        ]
    elif workflow == "Backtest Auditor" and files.get("metrics", Path()).exists():
        df = pd.read_csv(files["metrics"])
        lines += ["", "## 回测指标表", df.to_markdown(index=False)]
    elif workflow == "Premarket Agent":
        lines += ["", "## 结论", "输入已准备。需配置 LLM_API_KEY 才能生成自然语言盘前研究报告。"]
    elif workflow == "Postmarket Agent":
        lines += ["", "## 结论", "收益与成本由回测程序计算；需配置 LLM_API_KEY 才能生成行为复盘。"]
    elif workflow == "Investment Committee":
        lines += [
            "",
            "## 委员会范围",
            "离线模式已确认五因子、盘前、盘后、策略解释和回测输入文件存在。",
            "策略判断必须基于成长35%、质量25%、动量20%、低波12%、价值8%的五因子框架。",
        ]
        metrics_path = files.get("backtest_metrics", Path())
        if metrics_path.exists():
            metrics = pd.read_csv(metrics_path)
            lines += ["", "## 确定性回测指标", metrics.to_markdown(index=False)]
        lines += [
            "",
            "## 离线结论",
            "没有调用 LLM，不能完成 Bull/Bear/Risk/Chair 的自然语言综合判断。",
            "Instructor 应结合 Factor、Premarket、Postmarket、Strategy 和 Backtest Auditor 的缓存报告进行人工委员会讨论。",
        ]
    elif workflow == "Strategy Agent" and files.get("strategy_summary", Path()).exists():
        summary = json.loads(files["strategy_summary"].read_text(encoding="utf-8"))
        comp = summary.get("composite_score", {})
        port = summary.get("portfolio_construction", {})
        missing = summary.get("missing_risk_controls", {})
        lines += [
            "",
            "## 策略目标与数据日期",
            f"- 信号日期：{summary.get('latest_signal_date', 'N/A')}",
            f"- 回测区间：{summary.get('data_source', {}).get('backtest_start', '')} 至 {summary.get('data_source', {}).get('backtest_end', '')}",
            f"- 基准：{summary.get('data_source', {}).get('benchmark', {}).get('name', '')}",
            "",
            "## 股票池与可投资样本",
            f"- Universe：{summary.get('universe_count', 'N/A')} 只",
            f"- Eligible：{summary.get('eligible_count', 'N/A')} 只",
            f"- Selected：{summary.get('selected_count', 'N/A')} 只",
            "",
            "## 综合因子Score公式",
            f"- 公式：{comp.get('formula', 'N/A')}",
            f"- 权重：{comp.get('weights', {})}",
            f"- 优先级：{comp.get('priority_order', 'N/A')}",
            f"- 标准化：{comp.get('standardization', 'N/A')}",
            "",
            "## 因子定义及经济含义",
        ]
        for name, fdef in summary.get("factor_definitions", {}).items():
            lines.append(f"### {name}")
            lines.append(f"- 成分：{fdef.get('components', [])}")
            lines.append(f"- 内部权重：{fdef.get('internal_weights', [])}")
            lines.append(f"- 方向：{fdef.get('direction', '')}")
            if "missing_handling" in fdef:
                lines.append(f"- 缺失值处理：{fdef['missing_handling']}")
            lines.append("")

        lines += [
            "## 组合构建逻辑",
            f"- 选股数量：前 {port.get('top_k', 'N/A')} 名",
            f"- 行业约束：每行业最多 {port.get('max_names_per_industry', 'N/A')} 只",
            f"- 权重方式：{port.get('weighting', 'N/A')}",
            f"- 单股权重上限配置：{port.get('max_single_weight', 'N/A')}",
            f"- 行业权重上限：{port.get('industry_weight_cap', 'N/A')}",
            f"- 调仓频率：{port.get('rebalance', 'N/A')}",
            f"- 执行方式：{port.get('execution', 'N/A')}",
            f"- 单边交易成本：{port.get('one_way_cost_bps', 'N/A')} bps",
            "",
        ]

        # Selected stocks
        selected_stocks = summary.get("selected_stocks", [])
        if selected_stocks:
            lines += ["## 入选股票（最新信号日）", ""]
            lines.append("| 代码 | 名称 | 行业 | 综合Score | 权重 |")
            lines.append("|---|---|---|---:|---:|")
            for s in selected_stocks:
                lines.append(f"| {s.get('ts_code','')} | {s.get('name','')} | {s.get('industry_group','')} | {s.get('composite_score','N/A')} | {s.get('target_weight','N/A')} |")
            lines.append("")

        # Weight stats
        ws = summary.get("weight_statistics", {})
        if ws:
            lines += [
                "## 权重统计",
                f"- 最大权重：{ws.get('max_weight', 'N/A')}",
                f"- 最小权重：{ws.get('min_weight', 'N/A')}",
                f"- 平均权重：{ws.get('mean_weight', 'N/A')}",
                f"- HHI：{ws.get('hhi', 'N/A')}",
                "",
            ]

        # Industry concentration
        ic = summary.get("industry_concentration", {})
        if ic:
            lines += [
                "## 行业集中度",
                f"- 持仓行业数：{ic.get('num_industries', 'N/A')}",
                f"- 单行业最大持股数：{ic.get('max_holdings_in_one_industry', 'N/A')}",
                f"- 各行业持股：{ic.get('holdings_per_industry', {})}",
                "",
            ]

        # Missing risk controls
        lines += ["## 策略未实现的风险控制"]
        for k, v in missing.items():
            lines.append(f"- {k}：{v}")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("**Strategy Agent只解释当前确定性策略，不会修改因子、组合、权重或回测参数。**")

    elif workflow == "Data Quality Agent":
        dq_path = files.get("data_quality_summary", Path())
        if dq_path.exists():
            dq = json.loads(dq_path.read_text(encoding="utf-8"))
            s = dq.get("summary", {})
            lines += [
                "",
                "## 数据质量检查摘要",
                f"- 总检查项：{s.get('total_checks', 'N/A')}",
                f"- PASS: {s.get('PASS', 0)} | INFO: {s.get('INFO', 0)} | WARN: {s.get('WARN', 0)} | BLOCKER: {s.get('BLOCKER', 0)} | NOT_CHECKED: {s.get('NOT_CHECKED', 0)}",
                "",
            ]
            non_pass = [c for c in dq.get("checks", []) if c.get("severity") not in ("PASS",)]
            if non_pass:
                lines.append("## 非 PASS 项目")
                for c in non_pass:
                    lines.append(f"- [{c.get('severity')}] {c.get('check_id')}: {c.get('message')}")
                lines.append("")
            else:
                lines.append("## 结论：所有检查项全部 PASS，数据质量完好")
                lines.append("")

            # Endpoint status
            ep_status = dq.get("endpoint_status", {})
            optional_empty = [k for k, v in ep_status.items() if v.get("status") == "optional_empty"]
            if optional_empty:
                lines.append(f"## Optional endpoints（空）：{', '.join(optional_empty)}")
                lines.append("上述可选表为空（权限不足），不影响核心五因子回测流程。")
                lines.append("")

            # Ticker validation summary
            ticker_review = dq.get("ticker_review", [])
            valid_count = sum(1 for t in ticker_review if t.get("status") == "VALID")
            lines.append(f"## Ticker 验证：{valid_count}/{len(ticker_review)} 个 ticker 状态为 VALID")
            lines.append("")
        else:
            lines += ["", "## 结论", "请先运行 export 阶段生成 data_quality_summary.json。"]
    return "\n".join(lines)


def _single_prompt(root: Path, prompt_name: str, user_content: str) -> str:
    system = _read_text(root / "prompts" / prompt_name)
    client = OpenAICompatibleClient(load_llm_settings(root))
    return client.chat([
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ])


def run_workflow(workflow: str, root: str | Path | None = None, *, force_offline: bool = False) -> AgentResult:
    paths = project_paths(root)
    files = available_inputs(paths.root)
    _, source_mode = _data_base(paths.root)
    settings = load_llm_settings(paths.root)
    live = settings.configured and not force_offline and os.getenv("AGENT_MODE", "auto").lower() != "offline"

    # Auto-generate strategy summary if missing
    if workflow == "Strategy Agent" and not files["strategy_summary"].exists():
        from .export_agent_inputs import export_strategy_agent_summary
        agent_dir = files["strategy_summary"].parent
        export_strategy_agent_summary(paths.root, agent_inputs_dir=agent_dir)
        files = available_inputs(paths.root)

    # Auto-generate DQ summary if missing
    if workflow == "Data Quality Agent" and not files["data_quality_summary"].exists():
        from .data_quality import export_data_quality_summary
        agent_dir = files["data_quality_summary"].parent
        export_data_quality_summary(paths.root, agent_inputs_dir=agent_dir)
        files = available_inputs(paths.root)

    mapping = {
        "Data Quality Agent": ("06_tushare_data_quality_agent.txt", {
            "data_quality_summary": files["data_quality_summary"],
        }),
        "Factor Agent": ("01_factor_agent_system.txt", {"factor": files["factor"]}),
        "Premarket Agent": ("02_premarket_agent_system.txt", {
            "market": files["premarket_market"], "portfolio": files["premarket_portfolio"]
        }),
        "Postmarket Agent": ("03_postmarket_agent_system.txt", {
            "metrics": files["backtest_metrics"],
            "last_30_days": files["backtest_last_30_days"],
            "trade_log": files["trade_log"],
        }),
        "Strategy Agent": ("07_strategy_agent_system.txt", {
            "strategy_summary": files["strategy_summary"],
        }),
        "Backtest Auditor": ("05_backtest_auditor_system.txt", {
            "strategy": files["strategy_spec"],
            "metrics": files["backtest_metrics"],
            "rebalances": files["rebalance_log"],
        }),
    }
    if workflow not in mapping and workflow != "Investment Committee":
        raise KeyError(f"Unknown workflow: {workflow}")

    if workflow == "Investment Committee":
        source_files = {
            "factor_snapshot": files["factor"],
            "premarket_market": files["premarket_market"],
            "premarket_portfolio": files["premarket_portfolio"],
            "postmarket_metrics": files["backtest_metrics"],
            "postmarket_last_30_days": files["backtest_last_30_days"],
            "postmarket_trade_log": files["trade_log"],
            "backtest_strategy": files["strategy_spec"],
            "backtest_metrics": files["backtest_metrics"],
            "backtest_rebalances": files["rebalance_log"],
        }
        if not live:
            return AgentResult(
                workflow,
                _offline_report(paths.root, workflow, source_files, source_mode),
                "offline",
                [str(p) for p in source_files.values()],
            )

        try:
            # Generate the four prerequisite specialist reports inside the workflow so
            # the committee does not depend on which Streamlit tabs were clicked first.
            specialist_names = [
                "Factor Agent",
                "Premarket Agent",
                "Postmarket Agent",
                "Strategy Agent",
                "Backtest Auditor",
            ]
            specialist_results = {
                name: run_workflow(name, paths.root, force_offline=False)
                for name in specialist_names
            }
            deterministic_evidence = "\n\n".join(
                f"## Deterministic input: {name}\n{_read_text(path)}"
                for name, path in source_files.items()
            )
            specialist_evidence = "\n\n".join(
                f"## {name} output (mode={result.mode})\n{result.content}"
                for name, result in specialist_results.items()
            )
            evidence = (
                deterministic_evidence
                + "\n\n# Prior specialist reports\n\n"
                + specialist_evidence
            )

            client = OpenAICompatibleClient(settings)
            audit = client.chat([
                {
                    "role": "system",
                    "content": (
                        "你是Evidence Auditor。核对五个前序Agent报告与确定性CSV/策略规格。"
                        "指出不一致、无法核实、日期错误、因子权重错误和回测口径错误。"
                        "必须确认成长35%、质量25%、动量20%、低波12%、价值8%。"
                    ),
                },
                {"role": "user", "content": evidence},
            ])
            bull = client.chat([
                {
                    "role": "system",
                    "content": (
                        "你是Bull Analyst。基于Factor、Premarket、Postmarket和Backtest证据，"
                        "说明五因子策略可能有效的投资逻辑、实施优势和反证条件。"
                        "重点解释成长主导、质量过滤、动量确认、低波约束、价值纪律。"
                        "不得创造数据、给目标价或买卖建议。"
                    ),
                },
                {
                    "role": "user",
                    "content": evidence + "\n\n## Evidence Audit\n" + audit,
                },
            ])
            bear = client.chat([
                {
                    "role": "system",
                    "content": (
                        "你是Bear Analyst。攻击策略有效性与可行性假设，检查单年度样本、"
                        "固定Universe、成长周期性、参数和权重敏感性、因子拥挤、成本、"
                        "滑点、停牌涨跌停、行业偏移和盘前资料缺口。不得创造数据。"
                    ),
                },
                {
                    "role": "user",
                    "content": evidence + "\n\n## Audit\n" + audit + "\n\n## Bull\n" + bull,
                },
            ])
            risk = client.chat([
                {
                    "role": "system",
                    "content": (
                        "你是Risk Officer。综合五个前序Agent、审计、Bull和Bear，建立数据、"
                        "模型、组合、执行、行为和合规风险清单；区分观察项、WARN和BLOCKER，"
                        "并写出策略逻辑失效条件。"
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        evidence
                        + "\n\n## Audit\n" + audit
                        + "\n\n## Bull\n" + bull
                        + "\n\n## Bear\n" + bear
                    ),
                },
            ])
            chair_system = _read_text(paths.root / "prompts" / "04_investment_committee_prompts.md")
            chair = client.chat([
                {"role": "system", "content": chair_system},
                {
                    "role": "user",
                    "content": (
                        evidence
                        + "\n\n## Evidence Audit\n" + audit
                        + "\n\n## Bull\n" + bull
                        + "\n\n## Bear\n" + bear
                        + "\n\n## Risk\n" + risk
                    ),
                },
            ])
            content = (
                "# 五因子量化策略 Investment Committee\n\n"
                "## Evidence Audit\n" + audit
                + "\n\n## Bull\n" + bull
                + "\n\n## Bear\n" + bear
                + "\n\n## Risk\n" + risk
                + "\n\n## Committee Chair\n" + chair
            )
            all_sources = list(dict.fromkeys(
                [str(p) for p in source_files.values()]
                + [
                    source
                    for result in specialist_results.values()
                    for source in result.source_files
                ]
            ))
            return AgentResult(workflow, content, "live_llm", all_sources)
        except Exception as exc:
            fallback = _offline_report(paths.root, workflow, source_files, source_mode)
            content = (
                "# Live LLM unavailable - automatic offline fallback\n\n"
                f"Error: {type(exc).__name__}: {exc}\n\n{fallback}"
            )
            return AgentResult(
                workflow,
                content,
                "offline",
                [str(p) for p in source_files.values()],
            )

    prompt_name, source_files = mapping[workflow]
    if not live:
        return AgentResult(workflow, _offline_report(paths.root, workflow, source_files, source_mode), "offline", [str(p) for p in source_files.values()])
    user_content = "\n\n".join(f"## {name}\n{_read_text(path)}" for name, path in source_files.items())
    try:
        content = _single_prompt(paths.root, prompt_name, user_content)
        return AgentResult(workflow, content, "live_llm", [str(p) for p in source_files.values()])
    except Exception as exc:
        fallback = _offline_report(paths.root, workflow, source_files, source_mode)
        content = f"# Live LLM unavailable - automatic offline fallback\n\nError: {type(exc).__name__}: {exc}\n\n{fallback}"
        return AgentResult(workflow, content, "offline", [str(p) for p in source_files.values()])


def run_all_workflows(root: str | Path | None = None, *, force_offline: bool = False) -> list[AgentResult]:
    workflows = [
        "Data Quality Agent",
        "Factor Agent",
        "Premarket Agent",
        "Postmarket Agent",
        "Strategy Agent",
        "Backtest Auditor",
        "Investment Committee",
    ]
    return [run_workflow(name, root, force_offline=force_offline) for name in workflows]


def cache_agent_reports(root: str | Path | None = None, *, force_offline: bool = False) -> Path:
    paths = project_paths(root)
    cache = resolve_cache(paths.root)
    out = (cache / "agent_reports") if cache else (paths.root / "cached_outputs" / "current")
    out.mkdir(parents=True, exist_ok=True)
    for result in run_all_workflows(paths.root, force_offline=force_offline):
        safe = result.workflow.lower().replace(" ", "_")
        header = f"<!-- mode={result.mode}; sources={json.dumps(result.source_files, ensure_ascii=False)} -->\n"
        (out / f"{safe}.md").write_text(header + result.content, encoding="utf-8")
    return out
