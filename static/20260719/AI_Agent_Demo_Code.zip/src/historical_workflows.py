from __future__ import annotations

from pathlib import Path

import pandas as pd

from .common import load_config, load_frame, project_paths, save_frame


def build_historical_premarket_snapshot(root: str | Path | None = None) -> dict[str, Path]:
    paths = project_paths(root)
    cfg = load_config(root)
    market = load_frame(paths.processed / "market_panel")
    benchmark = load_frame(paths.processed / "benchmark_hs300")
    selected = load_frame(paths.processed / "selected_portfolios_2025")
    market["trade_date"] = pd.to_datetime(market["trade_date"])
    benchmark["trade_date"] = pd.to_datetime(benchmark["trade_date"])
    selected["signal_date"] = pd.to_datetime(selected["signal_date"])

    analysis_date = pd.Timestamp("2025-11-03")
    previous_dates = benchmark.loc[benchmark["trade_date"] < analysis_date, "trade_date"]
    previous_trade_date = previous_dates.max()
    market_row = benchmark[benchmark["trade_date"] == previous_trade_date].copy()
    market_row["analysis_date"] = analysis_date
    market_row["context"] = "历史盘前演示：使用前一交易日已知的沪深300数据"

    signal_date = selected.loc[selected["signal_date"] <= previous_trade_date, "signal_date"].max()
    portfolio = selected[selected["signal_date"] == signal_date].copy()
    portfolio["analysis_date"] = analysis_date
    portfolio["data_available_date"] = previous_trade_date

    out = {
        "market": paths.processed / "premarket_20251103_market",
        "portfolio": paths.processed / "premarket_20251103_portfolio",
    }
    save_frame(market_row, out["market"])
    save_frame(portfolio, out["portfolio"])
    return out


def build_simulated_trade_log(root: str | Path | None = None) -> Path:
    paths = project_paths(root)
    selected = load_frame(paths.processed / "selected_portfolios_2025")
    selected["signal_date"] = pd.to_datetime(selected["signal_date"])
    date = selected["signal_date"].max()
    names = selected[selected["signal_date"] == date].sort_values("rank").head(3)
    rows = []
    reasons = [
        (True, "月末规则调仓：进入前五且行业约束通过"),
        (True, "组合再平衡：按等权目标降低偏离"),
        (False, "盘中价格快速下跌，临时决定加仓"),
    ]
    for (_, row), (planned, reason) in zip(names.iterrows(), reasons):
        rows.append(
            {
                "trade_date": "2025-12-01",
                "ts_code": row["ts_code"],
                "name": row.get("name", ""),
                "side": "BUY" if planned else "ADD",
                "quantity": 1000,
                "reason": reason,
                "planned_trade": planned,
                "approved_by_human": True,
                "data_status": "simulated decision using Tushare-derived historical factor data",
            }
        )
    trade_log = pd.DataFrame(rows)
    out = paths.processed / "simulated_trade_log_2025"
    save_frame(trade_log, out)
    return out.with_suffix(".csv")
