from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .common import load_config, load_frame, project_paths


def export_agent_inputs(root: str | Path | None = None) -> list[Path]:
    paths = project_paths(root)
    cfg = load_config(root)
    out_dir = paths.processed / "agent_inputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    factor_panel = load_frame(paths.processed / "factor_panel_2025")
    metrics = load_frame(paths.processed / "backtest_2025_metrics")
    rebalances = load_frame(paths.processed / "backtest_2025_rebalances")
    timeseries = load_frame(paths.processed / "backtest_2025_timeseries")

    factor_panel["signal_date"] = pd.to_datetime(factor_panel["signal_date"])
    latest_date = factor_panel["signal_date"].max()
    latest = factor_panel[factor_panel["signal_date"] == latest_date].copy()
    factor_columns = [
        "ts_code", "name", "industry_group", "signal_date", "pe_ttm", "pb",
        "quality_roe", "ocf_to_or", "debt_to_assets",
        "revenue_growth_yoy", "profit_growth_yoy", "ocf_growth_yoy",
        "growth_metric_count", "momentum_12m_1m", "volatility_60d",
        "avg_amount_20d_thousand_cny", "growth_score", "quality_score",
        "momentum_score", "low_volatility_score", "value_score",
        "composite_score", "rank", "eligible", "selected", "target_weight",
        "ann_date", "end_date",
    ]
    factor_columns = [col for col in factor_columns if col in latest.columns]
    latest[factor_columns].to_csv(out_dir / "factor_snapshot_latest.csv", index=False, encoding="utf-8-sig")
    metrics.to_csv(out_dir / "backtest_metrics.csv", index=False, encoding="utf-8-sig")
    timeseries.tail(30).to_csv(out_dir / "backtest_last_30_days.csv", index=False, encoding="utf-8-sig")

    # Extended rebalance_log: include per-period portfolio holdings
    rebalance_rows = []
    for _, reb_row in rebalances.iterrows():
        sig_date = pd.to_datetime(reb_row["signal_date"])
        period_stocks = factor_panel[
            (factor_panel["signal_date"] == sig_date) & (factor_panel["selected"] == True)
        ].sort_values("composite_score", ascending=False)
        for _, stock in period_stocks.iterrows():
            rebalance_rows.append({
                "signal_date": reb_row["signal_date"],
                "execution_date": reb_row["execution_date"],
                "ts_code": stock["ts_code"],
                "name": stock.get("name", ""),
                "industry_group": stock.get("industry_group", ""),
                "composite_score": round(float(stock["composite_score"]), 6) if pd.notna(stock["composite_score"]) else None,
                "target_weight": round(float(stock["target_weight"]), 6) if pd.notna(stock["target_weight"]) else None,
                "turnover": reb_row.get("turnover", None),
                "transaction_cost": reb_row.get("transaction_cost", None),
            })
    rebalance_df = pd.DataFrame(rebalance_rows)
    rebalance_df.to_csv(out_dir / "rebalance_log.csv", index=False, encoding="utf-8-sig")

    strategy_md = f"""# A股2025量化策略规格

- 数据提供商：Tushare Pro
- 行情下载区间：{cfg['calendar']['download_start']} 至 {cfg['calendar']['download_end']}
- 正式回测区间：{cfg['calendar']['backtest_start']} 至 {cfg['calendar']['backtest_end']}
- 基准：{cfg['benchmark']['name']}（{cfg['benchmark']['ts_code']}）
- 调仓频率：月末信号、下一交易日执行
- 组合：前 {cfg['portfolio']['top_k']} 名，每行业最多 {cfg['portfolio']['max_names_per_industry']} 只，等权
- 单边交易成本：{cfg['portfolio']['one_way_cost_bps']} bps
- 因子权重（成长／质量／动量／低波／价值）：{cfg['features']['factor_weights']}
- 成长因子：40% 营收同比 + 40% 扣非净利润同比（缺失时用净利润同比）+ 20% 经营现金流同比；按可用项归一化
- 财务信息：仅使用 ann_date 不晚于信号日期的记录
- 课堂限制：不生成直接买卖指令，不连接真实券商账户
"""
    (out_dir / "strategy_spec.md").write_text(strategy_md, encoding="utf-8")
    export_strategy_agent_summary(root, agent_inputs_dir=out_dir)

    from .data_quality import export_data_quality_summary
    export_data_quality_summary(root, agent_inputs_dir=out_dir)

    return sorted(out_dir.iterdir())


def export_strategy_agent_summary(root: str | Path | None = None, *, agent_inputs_dir: Path | None = None) -> Path:
    """Generate a deterministic JSON summary for Strategy Agent input.

    Reads existing config, factor_snapshot_latest, and rebalance_log to produce
    a structured summary of the current strategy without re-running any computation.

    If agent_inputs_dir is provided, reads from and writes to that directory.
    Otherwise uses the default data/processed/agent_inputs.
    """
    paths = project_paths(root)
    cfg = load_config(root)
    out_dir = agent_inputs_dir if agent_inputs_dir else (paths.processed / "agent_inputs")
    out_dir.mkdir(parents=True, exist_ok=True)

    port_cfg = cfg["portfolio"]
    feat_cfg = cfg["features"]
    weights = feat_cfg["factor_weights"]

    # Read existing agent inputs
    factor_path = out_dir / "factor_snapshot_latest.csv"
    rebalance_path = out_dir / "rebalance_log.csv"
    strategy_spec_path = out_dir / "strategy_spec.md"

    summary: dict = {
        "meta": {
            "source": "export_strategy_agent_summary",
            "config_file": "config/course_config.yaml",
            "factor_snapshot_file": "data/processed/agent_inputs/factor_snapshot_latest.csv",
            "rebalance_log_file": "data/processed/agent_inputs/rebalance_log.csv",
            "strategy_spec_file": "data/processed/agent_inputs/strategy_spec.md",
        },
        "data_source": {
            "provider": cfg.get("provider", "tushare_pro"),
            "download_start": cfg["calendar"]["download_start"],
            "download_end": cfg["calendar"]["download_end"],
            "backtest_start": cfg["calendar"]["backtest_start"],
            "backtest_end": cfg["calendar"]["backtest_end"],
            "benchmark": cfg["benchmark"],
        },
        "factor_definitions": {
            "growth_score": {
                "components": ["revenue_growth_yoy", "profit_growth_yoy", "ocf_growth_yoy"],
                "internal_weights": [0.40, 0.40, 0.20],
                "direction": "positive",
                "missing_handling": "available-weight normalization",
            },
            "quality_score": {
                "components": ["quality_roe", "ocf_to_or", "debt_to_assets"],
                "internal_weights": [0.45, 0.25, 0.30],
                "direction": "positive (debt_to_assets is sign-flipped)",
                "missing_handling": "available-weight normalization",
            },
            "momentum_score": {
                "components": ["momentum_12m_1m"],
                "internal_weights": [1.0],
                "direction": "positive",
                "lookback_days": feat_cfg["momentum_lookback_days"],
                "skip_days": feat_cfg["momentum_skip_days"],
            },
            "low_volatility_score": {
                "components": ["volatility_60d"],
                "internal_weights": [1.0],
                "direction": "negative (sign-flipped: lower volatility = higher score)",
                "lookback_days": feat_cfg["volatility_lookback_days"],
            },
            "value_score": {
                "components": ["earnings_yield", "book_to_price"],
                "internal_weights": [0.50, 0.50],
                "direction": "positive",
                "missing_handling": "available-weight normalization",
            },
        },
        "composite_score": {
            "formula": "weighted_available(growth*w1 + quality*w2 + momentum*w3 + low_vol*w4 + value*w5)",
            "weights": weights,
            "priority_order": "growth > quality > momentum > low_volatility > value",
            "standardization": f"winsorize [{feat_cfg['winsor_lower']}, {feat_cfg['winsor_upper']}] then z-score within eligible",
        },
        "portfolio_construction": {
            "top_k": port_cfg["top_k"],
            "max_names_per_industry": port_cfg["max_names_per_industry"],
            "weighting": port_cfg["weighting"],
            "max_single_weight": port_cfg["max_single_weight"],
            "industry_weight_cap": "不存在（当前策略没有实现行业权重上限）",
            "rebalance": port_cfg["rebalance"],
            "one_way_cost_bps": port_cfg["one_way_cost_bps"],
            "execution": "signal on month_end, execute T+1",
        },
        "eligibility_criteria": {
            "pe_ttm": "> 0",
            "pb": "> 0",
            "min_avg_amount_thousand_cny": feat_cfg["min_avg_amount_thousand_cny"],
            "min_listing_days": cfg["universe"]["min_listing_days"],
            "exclude_st": True,
            "momentum_not_nan": True,
            "volatility_not_nan": True,
            "min_quality_metrics": "at least 1 of (roe, roe_dt, ocf_to_or, debt_to_assets)",
            "min_growth_metrics": "at least 2 of 3 growth metrics",
        },
    }

    # Add portfolio statistics from factor_snapshot_latest
    if factor_path.exists():
        df = pd.read_csv(factor_path)
        eligible = df[df["eligible"] == True] if "eligible" in df.columns else pd.DataFrame()
        selected = df[df["selected"] == True] if "selected" in df.columns else pd.DataFrame()

        summary["latest_signal_date"] = str(df["signal_date"].iloc[0]) if "signal_date" in df.columns and len(df) > 0 else None
        summary["universe_count"] = len(df)
        summary["eligible_count"] = len(eligible)
        summary["selected_count"] = len(selected)

        if not selected.empty:
            selected_list = []
            for _, row in selected.sort_values("composite_score", ascending=False).iterrows():
                entry = {
                    "ts_code": row.get("ts_code", ""),
                    "name": row.get("name", ""),
                    "industry_group": row.get("industry_group", ""),
                    "composite_score": round(float(row["composite_score"]), 4) if pd.notna(row.get("composite_score")) else None,
                    "target_weight": round(float(row["target_weight"]), 4) if pd.notna(row.get("target_weight")) else None,
                }
                for score_col in ["growth_score", "quality_score", "momentum_score", "low_volatility_score", "value_score"]:
                    if score_col in row.index and pd.notna(row[score_col]):
                        entry[score_col] = round(float(row[score_col]), 4)
                selected_list.append(entry)
            summary["selected_stocks"] = selected_list

            # Industry concentration
            industry_counts = selected["industry_group"].value_counts().to_dict()
            summary["industry_concentration"] = {
                "holdings_per_industry": {str(k): int(v) for k, v in industry_counts.items()},
                "num_industries": len(industry_counts),
                "max_holdings_in_one_industry": int(max(industry_counts.values())) if industry_counts else 0,
            }

            # Weight statistics
            tw = selected["target_weight"].astype(float)
            summary["weight_statistics"] = {
                "max_weight": round(float(tw.max()), 4),
                "min_weight": round(float(tw.min()), 4),
                "mean_weight": round(float(tw.mean()), 4),
                "hhi": round(float((tw ** 2).sum()), 6),
            }

            # Factor contributions
            factor_contribs = {}
            for score_col, w_key in [
                ("growth_score", "growth"),
                ("quality_score", "quality"),
                ("momentum_score", "momentum"),
                ("low_volatility_score", "low_volatility"),
                ("value_score", "value"),
            ]:
                if score_col in selected.columns:
                    vals = selected[score_col].astype(float)
                    factor_contribs[w_key] = {
                        "weight_in_composite": weights[w_key],
                        "mean_score_selected": round(float(vals.mean()), 4) if vals.notna().any() else None,
                        "std_score_selected": round(float(vals.std()), 4) if vals.notna().sum() > 1 else None,
                    }
            summary["factor_contributions"] = factor_contribs

    # Rebalance summary (handles both expanded and legacy format)
    if rebalance_path.exists():
        reb_df = pd.read_csv(rebalance_path)
        if not reb_df.empty:
            if "ts_code" in reb_df.columns:
                periods = reb_df.groupby("signal_date").agg(
                    num_stocks=("ts_code", "count"),
                    turnover=("turnover", "first"),
                    transaction_cost=("transaction_cost", "first"),
                ).reset_index()
            else:
                periods_list = []
                for _, row in reb_df.iterrows():
                    tickers = str(row.get("selected_tickers", "")).split(",")
                    periods_list.append({
                        "signal_date": row["signal_date"],
                        "num_stocks": len([t for t in tickers if t.strip()]),
                        "turnover": row.get("turnover"),
                        "transaction_cost": row.get("transaction_cost"),
                    })
                periods = pd.DataFrame(periods_list)
            summary["rebalance_summary"] = {
                "num_periods": len(periods),
                "periods": periods.to_dict("records"),
            }

    # Risk controls that do NOT exist
    summary["missing_risk_controls"] = {
        "industry_weight_cap": "当前策略没有实现行业权重上限",
        "single_stock_weight_cap_binding": f"配置为{port_cfg['max_single_weight']}，但等权{port_cfg['top_k']}只时为{round(1.0/port_cfg['top_k'], 4)}，未触发",
        "turnover_constraint": "当前策略没有实现换手率约束",
        "stop_loss": "当前策略没有实现止损机制",
        "tracking_error_budget": "当前策略没有实现跟踪误差预算",
    }

    out_path = out_dir / "strategy_agent_summary.json"
    out_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    return out_path
