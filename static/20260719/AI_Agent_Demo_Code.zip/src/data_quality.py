from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from .common import load_config, project_paths

TICKER_PATTERN = re.compile(r"^\d{6}\.(SH|SZ)$")

REQUIRED_ENDPOINTS = ["daily", "adj_factor", "daily_basic", "fina_indicator", "index_daily", "trade_cal", "stock_basic"]
OPTIONAL_ENDPOINTS = ["income", "balancesheet", "cashflow", "disclosure_date"]

PRIMARY_KEYS = {
    "daily": ["ts_code", "trade_date"],
    "adj_factor": ["ts_code", "trade_date"],
    "daily_basic": ["ts_code", "trade_date"],
    "fina_indicator": ["ts_code", "end_date", "ann_date"],
    "stock_basic": ["ts_code"],
    "trade_cal": ["cal_date"],
}


def _load_raw(raw_dir: Path, name: str) -> pd.DataFrame | None:
    for ext in (".parquet", ".csv"):
        path = raw_dir / f"{name}{ext}"
        if path.exists() and path.stat().st_size > 10:
            if ext == ".parquet":
                return pd.read_parquet(path)
            return pd.read_csv(path)
    return None


def _check_result(check_id: str, severity: str, message: str, **kwargs: Any) -> dict:
    result = {
        "check_id": check_id,
        "severity": severity,
        "message": message,
    }
    for k, v in kwargs.items():
        if v is not None:
            result[k] = v
    return result


def run_data_quality_checks(root: str | Path | None = None) -> dict:
    paths = project_paths(root)
    cfg = load_config(root)
    raw_dir = paths.raw / "snapshot_2025"

    universe_path = paths.root / cfg["universe"]["file"]
    universe_df = pd.read_csv(universe_path) if universe_path.exists() else pd.DataFrame()
    universe_tickers = set(universe_df["ts_code"].tolist()) if "ts_code" in universe_df.columns else set()

    stock_basic = _load_raw(raw_dir, "stock_basic")
    stock_basic_tickers = set(stock_basic["ts_code"].tolist()) if stock_basic is not None and "ts_code" in stock_basic.columns else set()

    checks: list[dict] = []

    # 1. Universe ticker format
    invalid_format = [t for t in universe_tickers if not TICKER_PATTERN.match(t)]
    if invalid_format:
        checks.append(_check_result(
            "universe_ticker_format", "WARN",
            f"{len(invalid_format)} tickers have invalid format (expected NNNNNN.SH or NNNNNN.SZ)",
            affected_tickers=invalid_format[:20],
            affected_rows=len(invalid_format),
        ))
    else:
        checks.append(_check_result(
            "universe_ticker_format", "PASS",
            f"All {len(universe_tickers)} universe tickers match NNNNNN.SH/SZ format",
            affected_rows=0,
        ))

    # 2. Universe vs stock_basic coverage
    if stock_basic is not None:
        missing_from_basic = sorted(universe_tickers - stock_basic_tickers)
        if missing_from_basic:
            checks.append(_check_result(
                "universe_vs_stock_basic", "WARN",
                f"{len(missing_from_basic)} universe tickers not found in stock_basic",
                affected_tickers=missing_from_basic[:20],
                affected_rows=len(missing_from_basic),
            ))
        else:
            checks.append(_check_result(
                "universe_vs_stock_basic", "PASS",
                f"All {len(universe_tickers)} universe tickers exist in stock_basic",
                affected_rows=0,
            ))
    else:
        checks.append(_check_result(
            "universe_vs_stock_basic", "NOT_CHECKED",
            "stock_basic file not found; cannot verify universe tickers",
        ))

    # 3. Required endpoint existence and row counts
    endpoint_status: dict[str, dict] = {}
    for ep in REQUIRED_ENDPOINTS:
        df = _load_raw(raw_dir, ep)
        if df is not None and len(df) > 0:
            tickers_in_ep = df["ts_code"].nunique() if "ts_code" in df.columns else 0
            endpoint_status[ep] = {"status": "success", "rows": len(df), "tickers": tickers_in_ep}
            checks.append(_check_result(
                f"endpoint_{ep}_exists", "PASS",
                f"{ep}: {len(df)} rows, {tickers_in_ep} tickers",
                affected_rows=0,
            ))
        else:
            endpoint_status[ep] = {"status": "missing_or_empty", "rows": 0, "tickers": 0}
            checks.append(_check_result(
                f"endpoint_{ep}_exists", "BLOCKER",
                f"Required endpoint {ep} is missing or empty",
                affected_rows=0,
                remediation=f"Re-run download to fetch {ep}",
            ))

    # 4. Optional endpoint status
    for ep in OPTIONAL_ENDPOINTS:
        df = _load_raw(raw_dir, ep)
        if df is not None and len(df) > 0:
            endpoint_status[ep] = {"status": "success", "rows": len(df), "tickers": df["ts_code"].nunique() if "ts_code" in df.columns else 0}
            checks.append(_check_result(
                f"endpoint_{ep}_optional", "PASS",
                f"Optional endpoint {ep}: {len(df)} rows",
                affected_rows=0,
            ))
        else:
            endpoint_status[ep] = {"status": "optional_empty", "rows": 0, "tickers": 0}
            checks.append(_check_result(
                f"endpoint_{ep}_optional", "INFO",
                f"Optional endpoint {ep} is empty (likely permission-gated); does not block core pipeline",
                affected_rows=0,
            ))

    # 5. Duplicate primary keys
    for ep, pk_cols in PRIMARY_KEYS.items():
        df = _load_raw(raw_dir, ep)
        if df is None or len(df) == 0:
            continue
        available_pk = [c for c in pk_cols if c in df.columns]
        if not available_pk:
            continue
        dup_mask = df.duplicated(subset=available_pk, keep=False)
        dup_count = int(dup_mask.sum())
        if dup_count > 0:
            exact_dup_count = int(df.duplicated(keep=False).sum())
            if ep == "fina_indicator" and exact_dup_count == dup_count:
                checks.append(_check_result(
                    f"duplicate_pk_{ep}", "WARN",
                    f"{ep} has {dup_count} exact-duplicate rows on {available_pk} (trivially deduped, common Tushare behavior)",
                    affected_rows=dup_count,
                    remediation=f"drop_duplicates() resolves this; pipeline handles it during processing",
                ))
            elif ep == "fina_indicator":
                conflicting = dup_count - exact_dup_count
                checks.append(_check_result(
                    f"duplicate_pk_{ep}", "WARN",
                    f"{ep} has {dup_count} PK-duplicate rows ({exact_dup_count} exact, {conflicting} with differing values); known Tushare report-revision behavior",
                    affected_rows=dup_count,
                    remediation=f"Deduplicate {ep} keeping latest ann_date per (ts_code, end_date)",
                ))
            else:
                checks.append(_check_result(
                    f"duplicate_pk_{ep}", "BLOCKER",
                    f"{ep} has {dup_count} duplicate rows on primary key {available_pk}",
                    affected_rows=dup_count,
                    remediation=f"Deduplicate {ep} on {available_pk}",
                ))
        else:
            checks.append(_check_result(
                f"duplicate_pk_{ep}", "PASS",
                f"{ep}: 0 duplicate primary keys on {available_pk}",
                affected_rows=0,
            ))

    # 6. Cross-table consistency (daily / adj_factor / daily_basic)
    daily = _load_raw(raw_dir, "daily")
    adj = _load_raw(raw_dir, "adj_factor")
    daily_basic = _load_raw(raw_dir, "daily_basic")

    if daily is not None and adj is not None and daily_basic is not None:
        daily_keys = set(zip(daily["ts_code"], daily["trade_date"])) if "ts_code" in daily.columns else set()
        adj_keys = set(zip(adj["ts_code"], adj["trade_date"])) if "ts_code" in adj.columns else set()
        db_keys = set(zip(daily_basic["ts_code"], daily_basic["trade_date"])) if "ts_code" in daily_basic.columns else set()

        missing_adj = daily_keys - adj_keys
        missing_db = daily_keys - db_keys
        extra_adj = adj_keys - daily_keys

        issues = []
        if missing_adj:
            issues.append(f"{len(missing_adj)} daily rows missing from adj_factor")
        if missing_db:
            issues.append(f"{len(missing_db)} daily rows missing from daily_basic")
        if extra_adj:
            issues.append(f"{len(extra_adj)} adj_factor rows not in daily")

        if issues:
            checks.append(_check_result(
                "cross_table_consistency", "WARN",
                "; ".join(issues),
                affected_rows=len(missing_adj) + len(missing_db) + len(extra_adj),
            ))
        else:
            checks.append(_check_result(
                "cross_table_consistency", "PASS",
                "daily, adj_factor, daily_basic are perfectly aligned (same ts_code x trade_date keys)",
                affected_rows=0,
            ))
    else:
        checks.append(_check_result(
            "cross_table_consistency", "NOT_CHECKED",
            "One or more core tables (daily/adj_factor/daily_basic) missing; cannot check consistency",
        ))

    # 7. Date coverage per ticker
    expected_days = 0
    trade_cal = _load_raw(raw_dir, "trade_cal")
    if daily is not None and trade_cal is not None and "ts_code" in daily.columns:
        cal_start = str(cfg["calendar"]["download_start"])
        cal_end = str(cfg["calendar"]["download_end"])
        trade_cal["cal_date"] = trade_cal["cal_date"].astype(str)
        if "is_open" in trade_cal.columns:
            open_dates = set(trade_cal[(trade_cal["is_open"] == 1) & (trade_cal["cal_date"] >= cal_start) & (trade_cal["cal_date"] <= cal_end)]["cal_date"])
        else:
            open_dates = set(trade_cal[(trade_cal["cal_date"] >= cal_start) & (trade_cal["cal_date"] <= cal_end)]["cal_date"])
        expected_days = len(open_dates)

        daily["trade_date"] = daily["trade_date"].astype(str)
        coverage_per_ticker = daily.groupby("ts_code")["trade_date"].nunique()
        low_coverage = coverage_per_ticker[coverage_per_ticker < expected_days * 0.9]

        if len(low_coverage) > 0:
            checks.append(_check_result(
                "date_coverage_per_ticker", "WARN",
                f"{len(low_coverage)} tickers have < 90% date coverage (expected ~{expected_days} trading days)",
                affected_tickers=low_coverage.index.tolist()[:20],
                affected_rows=int(low_coverage.sum()),
                evidence=f"Min coverage: {int(low_coverage.min())}/{expected_days}",
            ))
        else:
            checks.append(_check_result(
                "date_coverage_per_ticker", "PASS",
                f"All {len(coverage_per_ticker)} tickers have >= 90% date coverage ({expected_days} expected trading days)",
                affected_rows=0,
            ))
    else:
        checks.append(_check_result(
            "date_coverage_per_ticker", "NOT_CHECKED",
            "daily or trade_cal missing; cannot check per-ticker date coverage",
        ))

    # 8. fina_indicator ann_date completeness
    fina = _load_raw(raw_dir, "fina_indicator")
    if fina is not None and "ann_date" in fina.columns:
        null_ann = int(fina["ann_date"].isna().sum())
        if null_ann > 0:
            checks.append(_check_result(
                "fina_ann_date_null", "WARN",
                f"fina_indicator has {null_ann} rows with null ann_date (point-in-time risk)",
                affected_rows=null_ann,
                remediation="Rows with null ann_date cannot be used for point-in-time factor construction",
            ))
        else:
            checks.append(_check_result(
                "fina_ann_date_null", "PASS",
                f"fina_indicator: all {len(fina)} rows have non-null ann_date",
                affected_rows=0,
            ))
    elif fina is not None:
        checks.append(_check_result(
            "fina_ann_date_null", "BLOCKER",
            "fina_indicator exists but lacks ann_date column",
            remediation="Re-download fina_indicator with ann_date field",
        ))
    else:
        checks.append(_check_result(
            "fina_ann_date_null", "NOT_CHECKED",
            "fina_indicator not found",
        ))

    # 9. adj_factor positive values
    if adj is not None and "adj_factor" in adj.columns:
        non_positive = int((adj["adj_factor"] <= 0).sum())
        null_adj = int(adj["adj_factor"].isna().sum())
        if non_positive > 0 or null_adj > 0:
            checks.append(_check_result(
                "adj_factor_positive", "BLOCKER",
                f"adj_factor has {non_positive} non-positive and {null_adj} null values",
                affected_rows=non_positive + null_adj,
                remediation="Non-positive adj_factor causes incorrect return calculation",
            ))
        else:
            checks.append(_check_result(
                "adj_factor_positive", "PASS",
                f"adj_factor: all {len(adj)} values are positive and non-null",
                affected_rows=0,
            ))
    elif adj is not None:
        checks.append(_check_result(
            "adj_factor_positive", "NOT_CHECKED",
            "adj_factor table exists but lacks 'adj_factor' column",
        ))

    # 10. OHLC sanity (close > 0, high >= low, open/close within [low, high])
    if daily is not None:
        ohlc_issues = 0
        if all(c in daily.columns for c in ["open", "high", "low", "close"]):
            neg_close = int((daily["close"] <= 0).sum())
            high_lt_low = int((daily["high"] < daily["low"]).sum())
            close_out = int(((daily["close"] > daily["high"]) | (daily["close"] < daily["low"])).sum())
            ohlc_issues = neg_close + high_lt_low + close_out
            if ohlc_issues > 0:
                checks.append(_check_result(
                    "ohlc_sanity", "WARN",
                    f"OHLC issues: {neg_close} neg close, {high_lt_low} high<low, {close_out} close outside [low,high]",
                    affected_rows=ohlc_issues,
                ))
            else:
                checks.append(_check_result(
                    "ohlc_sanity", "PASS",
                    f"OHLC sanity: all {len(daily)} rows pass (close>0, high>=low, close in [low,high])",
                    affected_rows=0,
                ))

        if "vol" in daily.columns:
            neg_vol = int((daily["vol"] < 0).sum())
            if neg_vol > 0:
                checks.append(_check_result(
                    "negative_volume", "WARN",
                    f"{neg_vol} rows with negative volume",
                    affected_rows=neg_vol,
                ))
            else:
                checks.append(_check_result(
                    "negative_volume", "PASS",
                    "No negative volume values",
                    affected_rows=0,
                ))
    else:
        checks.append(_check_result(
            "ohlc_sanity", "NOT_CHECKED",
            "daily table not found",
        ))

    # 11. Ticker review (all universe tickers)
    ticker_review = []
    for ts_code in sorted(universe_tickers):
        entry: dict[str, Any] = {
            "ts_code": ts_code,
            "in_universe": True,
            "in_stock_basic": ts_code in stock_basic_tickers,
        }
        if stock_basic is not None and ts_code in stock_basic_tickers:
            row = stock_basic[stock_basic["ts_code"] == ts_code].iloc[0]
            entry["name"] = str(row.get("name", ""))
            entry["market"] = str(row.get("market", ""))
            entry["exchange"] = str(row.get("exchange", ""))

        if daily is not None and "ts_code" in daily.columns:
            ticker_daily = daily[daily["ts_code"] == ts_code]
            entry["daily_rows"] = len(ticker_daily)
            if expected_days > 0:
                entry["coverage_ratio"] = round(len(ticker_daily) / expected_days, 4)
            else:
                entry["coverage_ratio"] = None
        else:
            entry["daily_rows"] = 0
            entry["coverage_ratio"] = None

        if entry["in_stock_basic"] and entry.get("daily_rows", 0) > 0:
            entry["status"] = "VALID"
        elif entry["in_stock_basic"]:
            entry["status"] = "VALID_NO_DAILY"
        else:
            entry["status"] = "MISSING_FROM_STOCK_BASIC"

        ticker_review.append(entry)

    # Build summary
    severity_counts = {"PASS": 0, "INFO": 0, "WARN": 0, "BLOCKER": 0, "NOT_CHECKED": 0}
    for c in checks:
        sev = c.get("severity", "")
        if sev in severity_counts:
            severity_counts[sev] += 1

    result = {
        "meta": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "source": "src/data_quality.py",
            "raw_dir": str(raw_dir.relative_to(paths.root)),
            "config_file": "config/course_config.yaml",
            "universe_file": cfg["universe"]["file"],
        },
        "summary": {
            "total_checks": len(checks),
            **severity_counts,
        },
        "checks": checks,
        "ticker_review": ticker_review,
        "endpoint_status": endpoint_status,
    }
    return result


def export_data_quality_summary(root: str | Path | None = None, *, agent_inputs_dir: Path | None = None) -> Path:
    paths = project_paths(root)
    out_dir = agent_inputs_dir if agent_inputs_dir else (paths.processed / "agent_inputs")
    out_dir.mkdir(parents=True, exist_ok=True)

    result = run_data_quality_checks(root)
    out_path = out_dir / "data_quality_summary.json"
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    return out_path
