from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import tushare as ts
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from .common import load_config, project_paths, require_token, save_frame, write_manifest

LOGGER = logging.getLogger(__name__)


@dataclass
class DownloadSummary:
    endpoint: str
    rows: int
    path: str
    status: str
    message: str = ""


class TushareProvider:
    """Small, auditable Tushare Pro adapter for the course package."""

    def __init__(self, root: str | Path | None = None):
        self.paths = project_paths(root)
        self.cfg = load_config(root)
        self.token = require_token(root)
        ts.set_token(self.token)
        self.pro = ts.pro_api(self.token)
        self.interval = float(self.cfg["api"].get("request_interval_seconds", 0.18))
        self.max_retries = int(self.cfg["api"].get("max_retries", 5))
        self.raw_dir = self.paths.raw / "snapshot_2025"
        self.raw_dir.mkdir(parents=True, exist_ok=True)

    def _sleep(self) -> None:
        if self.interval > 0:
            time.sleep(self.interval)

    def _call_once(self, endpoint: str, **kwargs: Any) -> pd.DataFrame:
        fn: Callable[..., pd.DataFrame] = getattr(self.pro, endpoint)
        self._sleep()
        df = fn(**kwargs)
        if df is None:
            return pd.DataFrame()
        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Tushare endpoint {endpoint} returned {type(df)!r}, expected DataFrame")
        return df

    def call(self, endpoint: str, *, required: bool = True, **kwargs: Any) -> pd.DataFrame:
        @retry(
            stop=stop_after_attempt(self.max_retries),
            wait=wait_exponential(multiplier=1, min=1, max=20),
            retry=retry_if_exception_type(Exception),
            reraise=True,
        )
        def wrapped() -> pd.DataFrame:
            return self._call_once(endpoint, **kwargs)

        try:
            return wrapped()
        except Exception as exc:
            if required:
                raise RuntimeError(f"Required Tushare endpoint {endpoint} failed: {exc}") from exc
            LOGGER.warning("Optional endpoint %s failed: %s", endpoint, exc)
            return pd.DataFrame()

    def _save(self, endpoint: str, df: pd.DataFrame) -> DownloadSummary:
        out = self.raw_dir / endpoint
        save_frame(
            df,
            out,
            csv=bool(self.cfg["api"].get("save_raw_csv", True)),
            parquet=bool(self.cfg["api"].get("save_raw_parquet", True)),
        )
        return DownloadSummary(endpoint, len(df), str(out), "ok")

    def download_universe_and_calendar(self) -> list[DownloadSummary]:
        calendar = self.cfg["calendar"]
        stock_basic = self.call(
            "stock_basic",
            exchange="",
            list_status="L",
            fields="ts_code,symbol,name,area,industry,market,exchange,list_status,list_date,delist_date,is_hs",
        )
        trade_cal = self.call(
            "trade_cal",
            exchange=calendar.get("exchange", "SSE"),
            start_date=calendar["download_start"],
            end_date=calendar["download_end"],
            fields="exchange,cal_date,is_open,pretrade_date",
        )
        return [self._save("stock_basic", stock_basic), self._save("trade_cal", trade_cal)]

    def download_teaching_universe(self) -> list[DownloadSummary]:
        calendar = self.cfg["calendar"]
        universe_path = self.paths.root / self.cfg["universe"]["file"]
        universe = pd.read_csv(universe_path, dtype=str)
        tickers = universe["ts_code"].dropna().tolist()

        endpoint_frames: dict[str, list[pd.DataFrame]] = {
            "daily": [],
            "adj_factor": [],
            "daily_basic": [],
            "fina_indicator": [],
            "disclosure_date": [],
            "income": [],
            "balancesheet": [],
            "cashflow": [],
        }
        optional_statements = bool(self.cfg["api"].get("download_optional_financial_statements", True))
        financial_start = "20230101"
        financial_end = calendar["download_end"]

        for index, ticker in enumerate(tickers, start=1):
            LOGGER.info("Downloading %s (%d/%d)", ticker, index, len(tickers))
            endpoint_frames["daily"].append(
                self.call(
                    "daily",
                    ts_code=ticker,
                    start_date=calendar["download_start"],
                    end_date=calendar["download_end"],
                    fields="ts_code,trade_date,open,high,low,close,pre_close,change,pct_chg,vol,amount",
                )
            )
            endpoint_frames["adj_factor"].append(
                self.call(
                    "adj_factor",
                    ts_code=ticker,
                    start_date=calendar["download_start"],
                    end_date=calendar["download_end"],
                    fields="ts_code,trade_date,adj_factor",
                )
            )
            endpoint_frames["daily_basic"].append(
                self.call(
                    "daily_basic",
                    ts_code=ticker,
                    start_date=calendar["download_start"],
                    end_date=calendar["download_end"],
                    fields=(
                        "ts_code,trade_date,close,turnover_rate,turnover_rate_f,volume_ratio,"
                        "pe,pe_ttm,pb,ps_ttm,dv_ttm,total_share,float_share,free_share,total_mv,circ_mv"
                    ),
                )
            )
            endpoint_frames["fina_indicator"].append(
                self.call(
                    "fina_indicator",
                    ts_code=ticker,
                    start_date=financial_start,
                    end_date=financial_end,
                    fields=(
                        "ts_code,ann_date,end_date,roe,roe_dt,roa,roic,ocf_to_or,"
                        "debt_to_assets,netprofit_margin,grossprofit_margin,profit_dedt,"
                        "tr_yoy,or_yoy,netprofit_yoy,dt_netprofit_yoy,ocf_yoy"
                    ),
                )
            )
            endpoint_frames["disclosure_date"].append(
                self.call(
                    "disclosure_date",
                    required=False,
                    ts_code=ticker,
                    start_date=financial_start,
                    end_date=financial_end,
                )
            )
            if optional_statements:
                endpoint_frames["income"].append(
                    self.call(
                        "income",
                        required=False,
                        ts_code=ticker,
                        start_date=financial_start,
                        end_date=financial_end,
                        fields="ts_code,ann_date,f_ann_date,end_date,report_type,total_revenue,revenue,n_income_attr_p",
                    )
                )
                endpoint_frames["balancesheet"].append(
                    self.call(
                        "balancesheet",
                        required=False,
                        ts_code=ticker,
                        start_date=financial_start,
                        end_date=financial_end,
                        fields=(
                            "ts_code,ann_date,f_ann_date,end_date,report_type,total_assets,total_liab,"
                            "total_hldr_eqy_exc_min_int,money_cap,accounts_receiv,inventories"
                        ),
                    )
                )
                endpoint_frames["cashflow"].append(
                    self.call(
                        "cashflow",
                        required=False,
                        ts_code=ticker,
                        start_date=financial_start,
                        end_date=financial_end,
                        fields="ts_code,ann_date,f_ann_date,end_date,report_type,n_cashflow_act,c_pay_acq_const_fiolta",
                    )
                )

        summaries: list[DownloadSummary] = []
        required_endpoints = {"daily", "adj_factor", "daily_basic", "fina_indicator"}
        for endpoint, frames in endpoint_frames.items():
            nonempty = [frame for frame in frames if frame is not None and not frame.empty]
            if nonempty:
                original_columns = list(
                    dict.fromkeys(
                        column
                        for frame in nonempty
                        for column in frame.columns
                    )
                )
                cleaned_frames = [
                    frame.dropna(axis=1, how="all")
                    for frame in nonempty
                ]
                cleaned_frames = [
                    frame
                    for frame in cleaned_frames
                    if len(frame.columns) > 0
                ]
                if cleaned_frames:
                    combined = pd.concat(
                        cleaned_frames,
                        ignore_index=True,
                        sort=False,
                    ).reindex(columns=original_columns)
                else:
                    combined = pd.DataFrame(columns=original_columns)
            else:
                combined = pd.DataFrame()
            if endpoint in required_endpoints and combined.empty:
                raise RuntimeError(f"Required endpoint {endpoint} returned no rows for the teaching universe")
            summaries.append(self._save(endpoint, combined))

        benchmark = self.call(
            "index_daily",
            ts_code=self.cfg["benchmark"]["ts_code"],
            start_date=calendar["download_start"],
            end_date=calendar["download_end"],
            fields="ts_code,trade_date,open,high,low,close,pre_close,change,pct_chg,vol,amount",
        )
        summaries.append(self._save("index_daily", benchmark))
        write_manifest(
            self.raw_dir,
            {
                "provider": "Tushare Pro",
                "calendar": calendar,
                "universe_file": str(universe_path.relative_to(self.paths.root)),
                "tickers": tickers,
            },
        )
        return summaries

    def download_all(self) -> pd.DataFrame:
        summaries = self.download_universe_and_calendar() + self.download_teaching_universe()
        return pd.DataFrame([summary.__dict__ for summary in summaries])
