from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

from .common import load_config, load_frame, project_paths, save_frame

LOGGER = logging.getLogger(__name__)


def _winsorize(series: pd.Series, lower: float, upper: float) -> pd.Series:
    clean = series.astype(float)
    if clean.notna().sum() < 3:
        return clean
    lo, hi = clean.quantile([lower, upper])
    return clean.clip(lo, hi)


def _zscore(series: pd.Series) -> pd.Series:
    clean = series.astype(float)
    std = clean.std(ddof=0)
    if not np.isfinite(std) or std == 0:
        return pd.Series(np.nan, index=series.index)
    return (clean - clean.mean()) / std


def _weighted_available(frame: pd.DataFrame, columns: list[str], weights: list[float]) -> pd.Series:
    values = frame[columns].to_numpy(dtype=float)
    w = np.asarray(weights, dtype=float)
    available = np.isfinite(values)
    numerator = np.nansum(values * w, axis=1)
    denominator = np.sum(available * w, axis=1)
    return pd.Series(np.where(denominator > 0, numerator / denominator, np.nan), index=frame.index)


def _month_end_dates(open_dates: pd.DatetimeIndex, start: pd.Timestamp, end: pd.Timestamp) -> list[pd.Timestamp]:
    dates = pd.Series(open_dates[(open_dates >= start) & (open_dates <= end)])
    if dates.empty:
        return []
    return dates.groupby(dates.dt.to_period("M")).max().tolist()


def build_factor_panel(root: str | Path | None = None) -> pd.DataFrame:
    paths = project_paths(root)
    cfg = load_config(root)
    feat_cfg = cfg["features"]
    port_cfg = cfg["portfolio"]

    market = load_frame(paths.processed / "market_panel")
    financials = load_frame(paths.processed / "financial_panel")
    stock_master = load_frame(paths.processed / "stock_master")

    market["trade_date"] = pd.to_datetime(market["trade_date"])
    financials["ann_date"] = pd.to_datetime(financials["ann_date"])
    financials["end_date"] = pd.to_datetime(financials["end_date"])
    if "list_date" in stock_master.columns:
        stock_master["list_date"] = pd.to_datetime(stock_master["list_date"])

    price = market.pivot(index="trade_date", columns="ts_code", values="adj_close_return_equivalent").sort_index()
    amount = market.pivot(index="trade_date", columns="ts_code", values="amount").sort_index()
    pe = market.pivot(index="trade_date", columns="ts_code", values="pe_ttm").sort_index()
    pb = market.pivot(index="trade_date", columns="ts_code", values="pb").sort_index()
    daily_ret = price.pct_change(fill_method=None)

    start = pd.Timestamp(cfg["calendar"]["backtest_start"])
    end = pd.Timestamp(cfg["calendar"]["backtest_end"])
    signal_dates = _month_end_dates(price.index, start, end)
    lower = float(feat_cfg["winsor_lower"])
    upper = float(feat_cfg["winsor_upper"])
    weights = feat_cfg["factor_weights"]
    universe = pd.read_csv(paths.root / cfg["universe"]["file"], dtype=str).set_index("ts_code")

    rows: list[dict] = []
    for signal_date in signal_dates:
        loc = price.index.get_loc(signal_date)
        if isinstance(loc, slice):
            loc = loc.stop - 1
        lookback = int(feat_cfg["momentum_lookback_days"])
        skip = int(feat_cfg["momentum_skip_days"])
        vol_window = int(feat_cfg["volatility_lookback_days"])
        liq_window = int(feat_cfg["liquidity_lookback_days"])
        if loc < max(lookback, vol_window, liq_window) + 1:
            LOGGER.warning("Skipping %s: insufficient price history", signal_date.date())
            continue

        momentum = price.iloc[loc - skip] / price.iloc[loc - lookback] - 1
        volatility = daily_ret.iloc[loc - vol_window + 1 : loc + 1].std(ddof=0) * np.sqrt(252)
        avg_amount = amount.iloc[loc - liq_window + 1 : loc + 1].mean()
        pe_row = pe.loc[:signal_date].iloc[-1]
        pb_row = pb.loc[:signal_date].iloc[-1]

        snapshot = pd.DataFrame(index=price.columns)
        snapshot.index.name = "ts_code"
        snapshot["signal_date"] = signal_date
        snapshot["momentum_12m_1m"] = momentum
        snapshot["volatility_60d"] = volatility
        snapshot["avg_amount_20d_thousand_cny"] = avg_amount
        snapshot["pe_ttm"] = pe_row
        snapshot["pb"] = pb_row
        snapshot = snapshot.join(universe[["name", "industry_group", "teaching_role"]], how="left")

        # Point-in-time financial selection: only announcements known by the signal date.
        known = financials[financials["ann_date"] <= signal_date].copy()
        latest = (
            known.sort_values(["ts_code", "end_date", "ann_date"])
            .groupby("ts_code", as_index=False)
            .tail(1)
            .set_index("ts_code")
        )
        financial_cols = [
            col
            for col in [
                "ann_date", "end_date", "roe", "roe_dt", "ocf_to_or",
                "debt_to_assets", "netprofit_margin", "tr_yoy", "or_yoy",
                "netprofit_yoy", "dt_netprofit_yoy", "ocf_yoy",
            ]
            if col in latest.columns
        ]
        snapshot = snapshot.join(latest[financial_cols], how="left")

        if "list_date" in stock_master.columns:
            list_dates = stock_master.set_index("ts_code")["list_date"]
            snapshot["listing_days"] = (signal_date - list_dates).dt.days
        else:
            snapshot["listing_days"] = np.nan

        name_text = snapshot["name"].fillna("")
        snapshot["is_st_name"] = name_text.str.contains(r"ST|退", case=False, regex=True)
        snapshot["eligible"] = (
            snapshot["pe_ttm"].gt(0)
            & snapshot["pb"].gt(0)
            & snapshot["avg_amount_20d_thousand_cny"].ge(float(feat_cfg["min_avg_amount_thousand_cny"]))
            & snapshot["listing_days"].ge(int(cfg["universe"]["min_listing_days"]))
            & ~snapshot["is_st_name"]
            & snapshot["momentum_12m_1m"].notna()
            & snapshot["volatility_60d"].notna()
            & snapshot[[col for col in ["roe", "roe_dt", "ocf_to_or", "debt_to_assets"] if col in snapshot.columns]].notna().any(axis=1)
        )

        snapshot["earnings_yield"] = np.where(snapshot["pe_ttm"] > 0, 1.0 / snapshot["pe_ttm"], np.nan)
        snapshot["book_to_price"] = np.where(snapshot["pb"] > 0, 1.0 / snapshot["pb"], np.nan)
        quality_roe = snapshot["roe_dt"].combine_first(snapshot["roe"]) if "roe_dt" in snapshot else snapshot.get("roe")
        snapshot["quality_roe"] = quality_roe

        # Growth uses point-in-time cumulative YoY financial indicators from the latest
        # report known on the signal date. Prefer total revenue and deducted net profit;
        # fall back to operating revenue and reported net profit when needed.
        if "tr_yoy" in snapshot.columns:
            snapshot["revenue_growth_yoy"] = snapshot["tr_yoy"]
            if "or_yoy" in snapshot.columns:
                snapshot["revenue_growth_yoy"] = snapshot["revenue_growth_yoy"].combine_first(snapshot["or_yoy"])
        else:
            snapshot["revenue_growth_yoy"] = snapshot.get("or_yoy", np.nan)

        if "dt_netprofit_yoy" in snapshot.columns:
            snapshot["profit_growth_yoy"] = snapshot["dt_netprofit_yoy"]
            if "netprofit_yoy" in snapshot.columns:
                snapshot["profit_growth_yoy"] = snapshot["profit_growth_yoy"].combine_first(snapshot["netprofit_yoy"])
        else:
            snapshot["profit_growth_yoy"] = snapshot.get("netprofit_yoy", np.nan)

        snapshot["ocf_growth_yoy"] = snapshot.get("ocf_yoy", np.nan)
        growth_columns = ["revenue_growth_yoy", "profit_growth_yoy", "ocf_growth_yoy"]
        snapshot["growth_metric_count"] = snapshot[growth_columns].notna().sum(axis=1)
        snapshot["eligible"] &= snapshot["growth_metric_count"].ge(2)

        raw_factor_cols = {
            "earnings_yield": True,
            "book_to_price": True,
            "revenue_growth_yoy": True,
            "profit_growth_yoy": True,
            "ocf_growth_yoy": True,
            "quality_roe": True,
            "ocf_to_or": True,
            "debt_to_assets": False,
            "momentum_12m_1m": True,
            "volatility_60d": False,
        }
        eligible_index = snapshot.index[snapshot["eligible"]]
        for col, positive in raw_factor_cols.items():
            if col not in snapshot.columns:
                snapshot[f"z_{col}"] = np.nan
                continue
            series = snapshot.loc[eligible_index, col]
            clipped = _winsorize(series, lower, upper)
            z = _zscore(clipped)
            snapshot.loc[eligible_index, f"z_{col}"] = z if positive else -z

        snapshot["growth_score"] = _weighted_available(
            snapshot,
            ["z_revenue_growth_yoy", "z_profit_growth_yoy", "z_ocf_growth_yoy"],
            [0.40, 0.40, 0.20],
        )
        snapshot["quality_score"] = _weighted_available(
            snapshot,
            ["z_quality_roe", "z_ocf_to_or", "z_debt_to_assets"],
            [0.45, 0.25, 0.30],
        )
        snapshot["momentum_score"] = snapshot["z_momentum_12m_1m"]
        snapshot["low_volatility_score"] = snapshot["z_volatility_60d"]
        snapshot["value_score"] = _weighted_available(
            snapshot,
            ["z_earnings_yield", "z_book_to_price"],
            [0.5, 0.5],
        )
        # Composite is available-weight normalized. Configured importance is:
        # Growth > Quality > Momentum > Low Volatility > Value.
        snapshot["composite_score"] = _weighted_available(
            snapshot,
            [
                "growth_score", "quality_score", "momentum_score",
                "low_volatility_score", "value_score",
            ],
            [
                float(weights["growth"]), float(weights["quality"]),
                float(weights["momentum"]), float(weights["low_volatility"]),
                float(weights["value"]),
            ],
        )
        snapshot.loc[~snapshot["eligible"], "composite_score"] = np.nan
        snapshot["rank"] = snapshot["composite_score"].rank(ascending=False, method="min")

        selected: list[str] = []
        industry_counts: dict[str, int] = {}
        for ticker, row in snapshot.sort_values("composite_score", ascending=False).iterrows():
            if not bool(row["eligible"]) or not np.isfinite(row["composite_score"]):
                continue
            industry = str(row["industry_group"])
            if industry_counts.get(industry, 0) >= int(port_cfg["max_names_per_industry"]):
                continue
            selected.append(ticker)
            industry_counts[industry] = industry_counts.get(industry, 0) + 1
            if len(selected) >= int(port_cfg["top_k"]):
                break
        snapshot["selected"] = snapshot.index.isin(selected)
        snapshot["target_weight"] = 0.0
        if selected:
            snapshot.loc[selected, "target_weight"] = 1.0 / len(selected)

        rows.extend(snapshot.reset_index().to_dict("records"))

    panel = pd.DataFrame(rows).sort_values(["signal_date", "rank"], na_position="last")
    save_frame(panel, paths.processed / "factor_panel_2025")
    selected = panel[panel["selected"]].copy()
    save_frame(selected, paths.processed / "selected_portfolios_2025")
    LOGGER.info("Built factor panel with %d rows across %d signal dates", len(panel), panel["signal_date"].nunique())
    return panel
