from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

from .common import load_config, load_frame, project_paths, save_frame

LOGGER = logging.getLogger(__name__)


def performance_metrics(returns: pd.Series, turnover: pd.Series | None = None) -> dict[str, float]:
    clean = returns.dropna()
    if clean.empty:
        return {}
    equity = (1.0 + clean).cumprod()
    drawdown = equity / equity.cummax() - 1.0
    annual_return = equity.iloc[-1] ** (252.0 / len(clean)) - 1.0
    annual_vol = clean.std(ddof=1) * np.sqrt(252.0)
    return {
        "observations": float(len(clean)),
        "total_return": float(equity.iloc[-1] - 1.0),
        "annualized_return": float(annual_return),
        "annualized_volatility": float(annual_vol),
        "sharpe_rf0": float(annual_return / annual_vol) if annual_vol > 0 else np.nan,
        "max_drawdown": float(drawdown.min()),
        "positive_day_rate": float((clean > 0).mean()),
        "average_daily_turnover": float(turnover.reindex(clean.index).fillna(0).mean()) if turnover is not None else np.nan,
        "total_one_way_turnover": float(turnover.reindex(clean.index).fillna(0).sum()) if turnover is not None else np.nan,
    }


def run_backtest(root: str | Path | None = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    paths = project_paths(root)
    cfg = load_config(root)
    market = load_frame(paths.processed / "market_panel")
    factor_panel = load_frame(paths.processed / "factor_panel_2025")
    benchmark = load_frame(paths.processed / "benchmark_hs300")

    market["trade_date"] = pd.to_datetime(market["trade_date"])
    factor_panel["signal_date"] = pd.to_datetime(factor_panel["signal_date"])
    benchmark["trade_date"] = pd.to_datetime(benchmark["trade_date"])

    prices = market.pivot(index="trade_date", columns="ts_code", values="adj_close_return_equivalent").sort_index()
    returns = prices.pct_change(fill_method=None)
    benchmark = benchmark.set_index("trade_date").sort_index()
    benchmark_returns = benchmark["close"].pct_change(fill_method=None).rename("benchmark_return")

    target = factor_panel.pivot(index="signal_date", columns="ts_code", values="target_weight").sort_index()
    target = target.reindex(columns=prices.columns, fill_value=0.0)
    effective = pd.DataFrame(np.nan, index=prices.index, columns=prices.columns)
    rebalance_rows = []
    for signal_date, row in target.iterrows():
        later = prices.index[prices.index > signal_date]
        if later.empty:
            continue
        execution_date = later[0]
        effective.loc[execution_date] = row
        rebalance_rows.append(
            {
                "signal_date": signal_date,
                "execution_date": execution_date,
                "selected_tickers": ",".join(row.index[row > 0].tolist()),
            }
        )
    effective = effective.ffill().fillna(0.0)

    start = pd.Timestamp(cfg["calendar"]["backtest_start"])
    end = pd.Timestamp(cfg["calendar"]["backtest_end"])
    mask = (effective.index >= start) & (effective.index <= end)
    effective = effective.loc[mask]
    returns = returns.reindex(effective.index)
    gross = (effective.shift(1).fillna(0.0) * returns.fillna(0.0)).sum(axis=1)

    turnover = 0.5 * effective.diff().abs().sum(axis=1)
    if not turnover.empty:
        turnover.iloc[0] = 0.5 * effective.iloc[0].abs().sum()
    cost_rate = float(cfg["portfolio"]["one_way_cost_bps"]) / 10000.0
    transaction_cost = turnover * cost_rate
    net = gross - transaction_cost
    bench = benchmark_returns.reindex(effective.index).fillna(0.0)

    result = pd.DataFrame(
        {
            "trade_date": effective.index,
            "gross_return": gross.values,
            "turnover": turnover.values,
            "transaction_cost": transaction_cost.values,
            "net_return": net.values,
            "benchmark_return": bench.values,
        }
    ).set_index("trade_date")
    result["gross_equity"] = (1.0 + result["gross_return"]).cumprod()
    result["net_equity"] = (1.0 + result["net_return"]).cumprod()
    result["benchmark_equity"] = (1.0 + result["benchmark_return"]).cumprod()
    result["drawdown"] = result["net_equity"] / result["net_equity"].cummax() - 1.0

    metrics = pd.DataFrame(
        [
            {"series": "strategy_gross", **performance_metrics(result["gross_return"], turnover)},
            {"series": "strategy_net", **performance_metrics(result["net_return"], turnover)},
            {"series": "benchmark_hs300", **performance_metrics(result["benchmark_return"])},
        ]
    )
    rebalances = pd.DataFrame(rebalance_rows)
    if not rebalances.empty:
        rebalances["turnover"] = rebalances["execution_date"].map(turnover)
        rebalances["transaction_cost"] = rebalances["execution_date"].map(transaction_cost)

    save_frame(result.reset_index(), paths.processed / "backtest_2025_timeseries")
    save_frame(metrics, paths.processed / "backtest_2025_metrics")
    save_frame(effective.reset_index(names="trade_date"), paths.processed / "backtest_2025_weights")
    save_frame(rebalances, paths.processed / "backtest_2025_rebalances")
    LOGGER.info("Backtest completed with %d trading days", len(result))
    return result, metrics, rebalances
