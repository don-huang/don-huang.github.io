from __future__ import annotations

import argparse
import getpass
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"


def parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def write_env(values: dict[str, str]) -> None:
    template = (ROOT / ".env.example").read_text(encoding="utf-8").splitlines()
    output: list[str] = []
    seen: set[str] = set()
    for line in template:
        if "=" in line and not line.lstrip().startswith("#"):
            key = line.split("=", 1)[0].strip()
            if key in values:
                output.append(f"{key}={values[key]}")
                seen.add(key)
                continue
        output.append(line)
    for key, value in values.items():
        if key not in seen:
            output.append(f"{key}={value}")
    ENV_PATH.write_text("\n".join(output) + "\n", encoding="utf-8")


def run(command: list[str], *, allow_failure: bool = False) -> int:
    print("\n+", " ".join(command))
    result = subprocess.run(command, cwd=ROOT)
    if result.returncode and not allow_failure:
        raise SystemExit(result.returncode)
    return result.returncode


def ask_yes_no(prompt: str, default: bool = True) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    answer = input(f"{prompt} {suffix} ").strip().lower()
    if not answer:
        return default
    return answer in {"y", "yes", "1", "true"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Interactive Instructor first-run wizard")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--skip-download", action="store_true")
    parser.add_argument("--fixture", action="store_true", help="Software test only")
    parser.add_argument("--offline-agents", action="store_true")
    parser.add_argument("--cache-id", default="real_2025_course")
    args = parser.parse_args()

    print("Tushare A-share 2025 Instructor Setup Wizard")
    print("Project root:", ROOT)
    values = parse_env(ENV_PATH)

    if not args.non_interactive:
        token = values.get("TUSHARE_TOKEN", "")
        if not token or token == "replace_with_your_tushare_pro_token":
            token = getpass.getpass("Paste Tushare Pro token (hidden): ").strip()
            if token:
                values["TUSHARE_TOKEN"] = token

        if not args.offline_agents:
            current_key = values.get("LLM_API_KEY", "") or values.get("DEEPSEEK_API_KEY", "")
            if not current_key and ask_yes_no("Configure a live LLM for the Local Agent Lab?", True):
                values["LLM_API_KEY"] = getpass.getpass("Paste LLM API key (hidden): ").strip()
                values["LLM_BASE_URL"] = input(
                    f"LLM base URL [{values.get('LLM_BASE_URL', 'https://api.deepseek.com')}]: "
                ).strip() or values.get("LLM_BASE_URL", "https://api.deepseek.com")
                values["LLM_MODEL"] = input(
                    f"LLM model [{values.get('LLM_MODEL', 'deepseek-v4-flash')}]: "
                ).strip() or values.get("LLM_MODEL", "deepseek-v4-flash")
        write_env(values)
        print("Saved .env. Secrets were not printed.")

    run([sys.executable, "scripts/preflight.py", "--level", "offline"])

    if args.fixture:
        run([sys.executable, "scripts/load_fixture.py"])
        run([
            sys.executable, "scripts/prepare_classroom.py", "--skip-download", "--allow-fixture",
            "--offline-agent-reports", "--cache-id", "fixture_demo", "--skip-build",
        ])
        print("Fixture setup complete. This is NOT real 2025 market data.")
        return 0

    run([sys.executable, "scripts/preflight.py", "--level", "credentials"])
    command = [sys.executable, "scripts/prepare_classroom.py", "--cache-id", args.cache_id]
    if args.skip_download:
        command.append("--skip-download")
    if args.offline_agents:
        command.append("--offline-agent-reports")
    run(command)

    print("\nSetup complete.")
    print("Launch the classroom app with:")
    print("  bash scripts/run_local_agent_lab.sh")
    print("Open: http://127.0.0.1:8501")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
