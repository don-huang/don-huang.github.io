from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data_quality import TICKER_PATTERN, run_data_quality_checks


class TestTickerFormat:
    def test_valid_sh_ticker(self):
        assert TICKER_PATTERN.match("600519.SH")

    def test_valid_sz_ticker(self):
        assert TICKER_PATTERN.match("000001.SZ")

    def test_302_prefix_is_valid(self):
        assert TICKER_PATTERN.match("302132.SZ")

    def test_688_prefix_is_valid(self):
        assert TICKER_PATTERN.match("688001.SH")

    def test_301_prefix_is_valid(self):
        assert TICKER_PATTERN.match("301001.SZ")

    def test_invalid_format_rejected(self):
        assert not TICKER_PATTERN.match("AAPL")
        assert not TICKER_PATTERN.match("60051.SH")
        assert not TICKER_PATTERN.match("6005199.SH")
        assert not TICKER_PATTERN.match("600519.NY")


@pytest.fixture
def mini_raw_dir(tmp_path):
    """Create a minimal raw data directory for testing."""
    raw_dir = tmp_path / "data" / "raw" / "tushare" / "snapshot_2025"
    raw_dir.mkdir(parents=True)

    tickers = ["600519.SH", "000001.SZ", "302132.SZ"]
    dates = ["20250101", "20250102", "20250103", "20250106", "20250107"]

    # stock_basic
    stock_basic = pd.DataFrame({
        "ts_code": tickers,
        "name": ["贵州茅台", "平安银行", "中航成飞"],
        "market": ["主板", "主板", "主板"],
        "exchange": ["SSE", "SZSE", "SZSE"],
        "list_date": ["19970101", "19910403", "20000101"],
    })
    stock_basic.to_csv(raw_dir / "stock_basic.csv", index=False)

    # daily
    rows = []
    for t in tickers:
        for d in dates:
            rows.append({"ts_code": t, "trade_date": d, "open": 100, "high": 105, "low": 98, "close": 102, "vol": 10000, "amount": 1000000})
    daily = pd.DataFrame(rows)
    daily.to_csv(raw_dir / "daily.csv", index=False)

    # adj_factor
    adj_rows = []
    for t in tickers:
        for d in dates:
            adj_rows.append({"ts_code": t, "trade_date": d, "adj_factor": 1.5})
    adj = pd.DataFrame(adj_rows)
    adj.to_csv(raw_dir / "adj_factor.csv", index=False)

    # daily_basic
    db_rows = []
    for t in tickers:
        for d in dates:
            db_rows.append({"ts_code": t, "trade_date": d, "pe_ttm": 30, "pb": 5, "turnover_rate": 1.2})
    daily_basic = pd.DataFrame(db_rows)
    daily_basic.to_csv(raw_dir / "daily_basic.csv", index=False)

    # fina_indicator
    fina = pd.DataFrame({
        "ts_code": tickers,
        "end_date": ["20240930"] * 3,
        "ann_date": ["20241028"] * 3,
        "roe": [20.5, 15.3, 12.1],
    })
    fina.to_csv(raw_dir / "fina_indicator.csv", index=False)

    # trade_cal
    trade_cal = pd.DataFrame({
        "cal_date": dates + ["20250104", "20250105"],
        "is_open": [1, 1, 1, 1, 1, 0, 0],
    })
    trade_cal.to_csv(raw_dir / "trade_cal.csv", index=False)

    # index_daily
    idx = pd.DataFrame({"ts_code": ["000300.SH"] * 5, "trade_date": dates, "close": [4000] * 5})
    idx.to_csv(raw_dir / "index_daily.csv", index=False)

    # empty optional endpoints
    for ep in ["income", "balancesheet", "cashflow", "disclosure_date"]:
        (raw_dir / f"{ep}.csv").write_text("\n")

    # universe
    universe_path = tmp_path / "data" / "00_universe_ashare_2025.csv"
    universe_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"ts_code": tickers, "name": ["贵州茅台", "平安银行", "中航成飞"]}).to_csv(universe_path, index=False)

    # config
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    config = {
        "provider": "tushare_pro",
        "calendar": {"download_start": "20250101", "download_end": "20250107", "backtest_start": "20250101", "backtest_end": "20250107"},
        "universe": {"file": "data/00_universe_ashare_2025.csv", "min_listing_days": 365, "exclude_st": True, "exclude_suspended": True},
        "benchmark": {"ts_code": "000300.SH", "name": "沪深300"},
        "features": {"factor_weights": {"growth": 0.35, "quality": 0.25, "momentum": 0.20, "low_volatility": 0.12, "value": 0.08}, "momentum_lookback_days": 252, "momentum_skip_days": 21, "volatility_lookback_days": 60, "liquidity_lookback_days": 20, "min_avg_amount_thousand_cny": 100000, "winsor_lower": 0.025, "winsor_upper": 0.975},
        "portfolio": {"top_k": 10, "max_names_per_industry": 2, "weighting": "equal", "one_way_cost_bps": 15, "max_single_weight": 0.25, "rebalance": "month_end"},
    }
    import yaml
    (config_dir / "course_config.yaml").write_text(yaml.dump(config, allow_unicode=True))

    return tmp_path


class TestDataQualityChecks:
    def test_all_pass_with_clean_data(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        blockers = [c for c in result["checks"] if c["severity"] == "BLOCKER"]
        assert len(blockers) == 0, f"Unexpected blockers: {blockers}"

    def test_302_prefix_not_rejected(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        ticker_review = result["ticker_review"]
        t302 = [t for t in ticker_review if t["ts_code"] == "302132.SZ"]
        assert len(t302) == 1
        assert t302[0]["status"] == "VALID"
        assert t302[0]["in_stock_basic"] is True
        assert t302[0]["in_universe"] is True

    def test_no_ticker_replacement_suggested(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        result_json = json.dumps(result)
        assert "替换" not in result_json
        assert "replace" not in result_json.lower()

    def test_stock_basic_existence_check(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        check = next(c for c in result["checks"] if c["check_id"] == "universe_vs_stock_basic")
        assert check["severity"] == "PASS"

    def test_duplicate_pk_detected(self, mini_raw_dir):
        # Add a duplicate row to daily
        daily_path = mini_raw_dir / "data" / "raw" / "tushare" / "snapshot_2025" / "daily.csv"
        df = pd.read_csv(daily_path)
        df = pd.concat([df, df.iloc[[0]]], ignore_index=True)
        df.to_csv(daily_path, index=False)

        result = run_data_quality_checks(mini_raw_dir)
        dup_check = next(c for c in result["checks"] if c["check_id"] == "duplicate_pk_daily")
        assert dup_check["severity"] == "BLOCKER"
        assert dup_check["affected_rows"] > 0

    def test_cross_table_consistency_pass(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        check = next(c for c in result["checks"] if c["check_id"] == "cross_table_consistency")
        assert check["severity"] == "PASS"

    def test_cross_table_mismatch_detected(self, mini_raw_dir):
        # Remove one row from adj_factor to create mismatch
        adj_path = mini_raw_dir / "data" / "raw" / "tushare" / "snapshot_2025" / "adj_factor.csv"
        df = pd.read_csv(adj_path)
        df = df.iloc[1:]
        df.to_csv(adj_path, index=False)

        result = run_data_quality_checks(mini_raw_dir)
        check = next(c for c in result["checks"] if c["check_id"] == "cross_table_consistency")
        assert check["severity"] == "WARN"

    def test_ann_date_null_detected(self, mini_raw_dir):
        fina_path = mini_raw_dir / "data" / "raw" / "tushare" / "snapshot_2025" / "fina_indicator.csv"
        df = pd.read_csv(fina_path)
        df.loc[0, "ann_date"] = None
        df.to_csv(fina_path, index=False)

        result = run_data_quality_checks(mini_raw_dir)
        check = next(c for c in result["checks"] if c["check_id"] == "fina_ann_date_null")
        assert check["severity"] == "WARN"
        assert check["affected_rows"] == 1

    def test_adj_factor_non_positive_detected(self, mini_raw_dir):
        adj_path = mini_raw_dir / "data" / "raw" / "tushare" / "snapshot_2025" / "adj_factor.csv"
        df = pd.read_csv(adj_path)
        df.loc[0, "adj_factor"] = 0
        df.to_csv(adj_path, index=False)

        result = run_data_quality_checks(mini_raw_dir)
        check = next(c for c in result["checks"] if c["check_id"] == "adj_factor_positive")
        assert check["severity"] == "BLOCKER"

    def test_ohlc_sanity_detected(self, mini_raw_dir):
        daily_path = mini_raw_dir / "data" / "raw" / "tushare" / "snapshot_2025" / "daily.csv"
        df = pd.read_csv(daily_path)
        df.loc[0, "high"] = 50  # less than low=98
        df.to_csv(daily_path, index=False)

        result = run_data_quality_checks(mini_raw_dir)
        check = next(c for c in result["checks"] if c["check_id"] == "ohlc_sanity")
        assert check["severity"] == "WARN"

    def test_optional_endpoint_empty_is_info_not_blocker(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        optional_checks = [c for c in result["checks"] if "optional" in c["check_id"]]
        for c in optional_checks:
            assert c["severity"] in ("PASS", "INFO"), f"Optional endpoint should not block: {c}"

    def test_endpoint_status_structure(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        ep = result["endpoint_status"]
        assert "daily" in ep
        assert ep["daily"]["status"] == "success"
        assert ep["daily"]["rows"] > 0
        for optional in ["income", "balancesheet", "cashflow", "disclosure_date"]:
            assert ep[optional]["status"] == "optional_empty"

    def test_summary_counts_correct(self, mini_raw_dir):
        result = run_data_quality_checks(mini_raw_dir)
        s = result["summary"]
        total = s["PASS"] + s["INFO"] + s["WARN"] + s["BLOCKER"] + s["NOT_CHECKED"]
        assert total == s["total_checks"]


class TestDQOfflineReport:
    def test_offline_report_does_not_mention_invalid_ticker(self):
        from src.agent_workflows import run_workflow
        result = run_workflow("Data Quality Agent", ROOT, force_offline=True)
        assert "无效" not in result.content or "ticker" not in result.content.lower()
        assert "302132" not in result.content or "VALID" in result.content

    def test_offline_report_contains_summary(self):
        from src.agent_workflows import run_workflow
        result = run_workflow("Data Quality Agent", ROOT, force_offline=True)
        assert result.mode == "offline"
        assert "数据质量" in result.content


class TestRegressionStrategyUnchanged:
    def test_factor_backtest_files_exist(self):
        from src.agent_workflows import available_inputs
        files = available_inputs(ROOT)
        assert files["factor"].exists()
        assert files["backtest_metrics"].exists()
        assert files["rebalance_log"].exists()
