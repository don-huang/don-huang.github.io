from pathlib import Path
import subprocess
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def test_fixture_pipeline():
    subprocess.run([sys.executable, str(ROOT / "scripts" / "generate_fixture.py")], check=True)
    raw = ROOT / "data" / "raw" / "tushare" / "snapshot_2025"
    raw.mkdir(parents=True, exist_ok=True)
    fixture = ROOT / "data" / "fixtures" / "tushare_schema_fixture"
    for path in fixture.glob("*.csv"):
        (raw / path.name).write_bytes(path.read_bytes())

    from src.dataset import build_processed_dataset
    from src.features import build_factor_panel
    from src.backtest import run_backtest

    build_processed_dataset(ROOT)
    panel = build_factor_panel(ROOT)
    result, metrics, _ = run_backtest(ROOT)
    assert not panel.empty
    assert panel["selected"].any()
    assert "growth_score" in panel.columns
    assert panel.loc[panel["eligible"], "growth_score"].notna().all()
    assert not result.empty
    assert set(metrics["series"]) == {"strategy_gross", "strategy_net", "benchmark_hs300"}
