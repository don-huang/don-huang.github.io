from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.agent_workflows import run_workflow
from src.cache_manager import resolve_cache, verify_cache
from src.common import load_config


def test_fixture_cache_is_portable_and_valid():
    cache = resolve_cache(ROOT)
    assert cache is not None
    assert cache.exists()
    assert not verify_cache(cache)


def test_five_factor_weights_follow_requested_order():
    weights = load_config(ROOT)["features"]["factor_weights"]
    assert weights == {
        "growth": 0.35,
        "quality": 0.25,
        "momentum": 0.20,
        "low_volatility": 0.12,
        "value": 0.08,
    }
    assert (
        weights["growth"]
        > weights["quality"]
        > weights["momentum"]
        > weights["low_volatility"]
        > weights["value"]
    )


def test_portfolio_top_k_is_10():
    cfg = load_config(ROOT)
    assert cfg["portfolio"]["top_k"] == 10


def test_all_agent_workflows_have_offline_fallbacks():
    workflows = [
        "Data Quality Agent",
        "Factor Agent",
        "Premarket Agent",
        "Postmarket Agent",
        "Strategy Agent",
        "Backtest Auditor",
        "Investment Committee",
    ]
    for name in workflows:
        result = run_workflow(name, ROOT, force_offline=True)
        assert result.mode == "offline"
        assert len(result.content) > 100


def test_strategy_agent_offline_contains_key_sections():
    result = run_workflow("Strategy Agent", ROOT, force_offline=True)
    assert result.mode == "offline"
    assert "Strategy Agent" in result.content
    assert "不会修改因子" in result.content or "离线确定性摘要" in result.content


def test_strategy_committee_uses_all_prior_evidence():
    result = run_workflow("Investment Committee", ROOT, force_offline=True)
    source_names = {Path(path).name for path in result.source_files}
    assert {
        "factor_snapshot_latest.csv",
        "premarket_20251103_market.csv",
        "premarket_20251103_portfolio.csv",
        "backtest_metrics.csv",
        "backtest_last_30_days.csv",
        "simulated_trade_log_2025.csv",
        "strategy_spec.md",
        "rebalance_log.csv",
    }.issubset(source_names)
    assert "成长35%" in result.content
    assert "Factor、Premarket、Postmarket、Strategy 和 Backtest Auditor" in result.content
