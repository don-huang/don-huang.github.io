from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.agent_workflows import available_inputs, run_workflow
from src.cache_manager import detect_provenance, resolve_cache, verify_cache
from src.llm_client import load_llm_settings


st.set_page_config(page_title="A股2025 Local Agent Lab", page_icon="📊", layout="wide")
st.title("A股2025 Local Agent Lab")
st.caption("Tushare Pro 数据＋本地缓存＋OpenAI-compatible LLM。无须 Dify 即可完成课堂 Agent Demo。")

settings = load_llm_settings(ROOT)
cache_root = ROOT / "classroom_cache" / "snapshots"
cache_names = sorted([path.name for path in cache_root.iterdir() if path.is_dir()]) if cache_root.exists() else []
latest_cache = resolve_cache(ROOT)
default_index = cache_names.index(latest_cache.name) if latest_cache and latest_cache.name in cache_names else 0

with st.sidebar:
    st.header("Instructor 状态")
    selected_cache = st.selectbox(
        "Classroom cache",
        cache_names or ["未准备"],
        index=default_index if cache_names else 0,
        help="正式课堂选择 real_2025_course；fixture_demo 只用于软件测试。",
    )
    if cache_names:
        os.environ["CLASSROOM_CACHE_ID"] = selected_cache
        cache = resolve_cache(ROOT, selected_cache)
    else:
        cache = None

    cache_metadata = {}
    if cache and (cache / "CACHE_METADATA.json").exists():
        cache_metadata = json.loads((cache / "CACHE_METADATA.json").read_text(encoding="utf-8"))
    provenance = cache_metadata.get("provenance", detect_provenance(ROOT))
    st.write("数据来源：", provenance.get("kind", "unknown"))
    if provenance.get("classroom_eligible"):
        st.success("当前 cache 来自真实 Tushare 快照")
    else:
        st.warning("当前 cache 是 fixture 或未经验证数据，不能作为真实2025市场证据")
    st.write("LLM：", settings.model if settings.configured else "未配置，使用离线摘要")
    st.write("Cache：", cache.name if cache else "未准备")
    force_offline = st.checkbox("强制离线模式", value=not settings.configured)
    if cache:
        issues = verify_cache(cache)
        st.write("Cache 校验：", "通过" if not issues else f"失败 ({len(issues)})")
        st.caption(cache_metadata.get("warning", ""))
    st.divider()
    st.code("bash scripts/run_local_agent_lab.sh")

workflow_names = [
    "Data Quality Agent",
    "Factor Agent",
    "Premarket Agent",
    "Postmarket Agent",
    "Strategy Agent",
    "Backtest Auditor",
    "Investment Committee",
]

tabs = st.tabs(["总览"] + workflow_names)

with tabs[0]:
    st.subheader("完整课堂流程")
    st.markdown(
        """
1. **Tushare Data Quality Agent**：检查 endpoint、覆盖、重复和 `ann_date`。
2. **Factor Agent**：解释成长、质量、动量、低波、价值和行业约束。
3. **Premarket Agent**：基于历史截止日整理市场与持仓风险。
4. **Postmarket Agent**：解释策略、沪深300、成本和计划外交易。
5. **Strategy Agent**：解释当前确定性策略的构建逻辑、因子权重、选股规则、组合构建和风险控制。只解释，不修改策略。
6. **Backtest Auditor**：检查前视偏差、执行时点、成本、基准与幸存者偏差。
7. **Investment Committee**：综合前述因子、盘前、盘后、策略解释和回测结果，由 Audit / Bull / Bear / Risk / Chair 判断策略有效性与可行性。
        """
    )
    inputs = available_inputs(ROOT)
    st.subheader("输入文件状态")
    st.dataframe(
        [{"input": key, "path": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path), "exists": path.exists()} for key, path in inputs.items()],
        width="stretch",
    )
    st.info("正式课堂建议使用已冻结的真实 classroom cache。没有 LLM 时仍可展示确定性离线摘要。")

for tab, workflow in zip(tabs[1:], workflow_names):
    with tab:
        st.subheader(workflow)
        st.write("点击后读取当前 classroom cache 或 processed 数据。所有数字由代码生成；LLM 只解释和审计。")
        if st.button(f"运行 {workflow}", key=workflow):
            with st.spinner("运行中..."):
                try:
                    result = run_workflow(workflow, ROOT, force_offline=force_offline)
                    st.session_state[f"result_{workflow}"] = result
                except Exception as exc:
                    st.error(f"运行失败：{exc}")
        result = st.session_state.get(f"result_{workflow}")
        if result:
            if result.mode == "offline":
                st.warning("当前为离线确定性摘要，不是 LLM 生成报告。")
            else:
                st.success(f"Live LLM：{settings.model}")
            st.markdown(result.content)
            st.download_button(
                "下载 Markdown",
                data=result.content,
                file_name=workflow.lower().replace(" ", "_") + ".md",
                mime="text/markdown",
                key=f"download_{workflow}",
            )
            with st.expander("查看输入来源"):
                st.json(result.source_files)

st.divider()
st.caption("教学用途。不得连接真实券商账户，不构成投资建议，不保证未来收益。")
