# AI Agent Demo China — Tushare Pro A-share 2025 v10 Growth + Strategy Agent + IC

## What this package now includes

- Tushare Pro downloader for 2024-2025 A-share data.
- Point-in-time financial-data processing by `ann_date`.
- Growth, quality, momentum, low-volatility and value factor model, weighted 35%/25%/20%/12%/8%.
- Monthly ten-stock portfolio (top_k=10) and 2025 backtest against CSI 300.
- Transaction costs, turnover, drawdown and execution-lag controls.
- Moutai vs Wuliangye historical comparison evidence pack retained as a separate teaching case.
- Seven AI Agent workflows, including a Strategy Agent that explains the current deterministic strategy without modifying it, and a strategy-level Investment Committee that synthesizes Factor, Premarket, Postmarket, Strategy and Backtest evidence.
- A built-in Streamlit Local Agent Lab, so Dify is optional.
- Interactive Instructor setup wizard.
- Four-level preflight checker.
- Portable, checksummed classroom cache.
- Synthetic offline fixture and cached fallback reports.
- Optional Dify workflow specifications and export procedure.
- Mac and Windows bootstrap scripts.
- `requirements_tested_lock.txt` recording the exact versions used in package validation.


## Upgrading from v8

The v8 `fina_indicator` snapshot may not contain the Growth fields required by v9. Do not reuse an old v8 factor panel or classroom cache as the v9 result. Run a fresh Tushare download without `--skip-download`, rebuild the pipeline, and create a new cache such as `real_2025_course_v9_growth`.

## External credentials still required

For real classroom data:

1. a Tushare Pro token with access to the required endpoints;
2. one OpenAI-compatible LLM API key for live Agent reports.

The package cannot legally bundle your paid Tushare raw data or your private API keys.

## Fastest Mac route

```bash
bash scripts/bootstrap_mac.sh
```

Edit `.env`, then run:

```bash
python instructor_setup.py
```

Launch the classroom app:

```bash
bash scripts/run_local_agent_lab.sh
```

Open:

```text
http://127.0.0.1:8501
```

## Final readiness test

```bash
python scripts/preflight.py --level full
```

Proceed only when the final line is `READY`.

## Offline software test

```bash
python instructor_setup.py --fixture --offline-agents
```

The fixture contains synthetic numerical values. It must never be presented as real 2025 market evidence.

## Read these first

1. `QUICK_START_ONE_PAGE.md`
2. `INSTRUCTOR_REQUIRED_ACTIONS.md`
3. `AI_Agent_Demo_Instructor_Manual_China_Tushare_Ashare_2025_v9_Growth_IC.pdf`
4. `CLASSROOM_REHEARSAL_CHECKLIST.md`
5. `DATA_LICENSE_AND_CLASSROOM_NOTICE.md`

## Core classroom path

```text
Tushare API
-> raw snapshot and manifest
-> point-in-time processed data
-> factors and portfolio
-> 2025 backtest
-> classroom cache
-> Local Agent Lab
-> human review
```

The full Manual also retains detailed Dify, Activepieces, OpenBB, FinRobot, TradingAgents and RD-Agent(Q) Instructor procedures. These remain optional extensions and are not required for the core class.
