# Optional Dify Path: Build, Test, Export, and Freeze

The built-in `Local Agent Lab` is the required classroom path. Dify is optional.

This directory contains portable workflow specifications, not fabricated Dify DSL. Dify's exported DSL contains version-specific node IDs, provider identifiers and model metadata. The reliable procedure is therefore:

1. pin and install a tested Dify release;
2. build the six workflows from the included specifications;
3. test every workflow with the generated Agent input files;
4. export the DSL from that Dify instance;
5. save the exports in `dify/exported_dsl/`;
6. import the exports into a blank test workspace;
7. run the full preflight again.

## Tested target

The manual targets Dify Community Edition 1.15.0. Do not upgrade immediately before class.

## Self-hosted Dify

```bash
git clone --branch 1.15.0 --depth 1 https://github.com/langgenius/dify.git
cd dify/docker
cp .env.example .env
docker compose up -d
```

Open:

```text
http://localhost/install
```

Minimum upstream requirement is 2 CPU cores and 4 GiB RAM; 4 cores and 8-16 GiB are preferable for a classroom computer.

## Model provider

Install and configure one provider in Dify. For DeepSeek, use the current model configured in this package's `.env`, or another provider already tested at the teaching venue.

Never place API keys inside prompts or DSL files.

## Build sequence

For each YAML file under `workflow_specs/`:

1. Studio -> Create from Blank -> Workflow.
2. Use the `app_name` value.
3. Add Start/User Input variables exactly as specified.
4. Add LLM nodes with the specified prompt file and temperature.
5. Connect edges in the listed order.
6. Add Output variables.
7. Preview with files from `data/processed/agent_inputs/`.
8. Publish the workflow.
9. Export the DSL from the app menu.
10. Save it under `dify/exported_dsl/` using the same base name.

## Validate exported DSL

Create a blank Dify workspace and import each exported DSL. Reconnect the model provider if necessary. Then run the same input files again.

## Dify API smoke test

Create an app API key inside one published workflow, then add to `.env`:

```text
DIFY_BASE_URL=http://localhost/v1
DIFY_API_KEY=app-...
```

Run:

```bash
python scripts/test_dify_api.py
python scripts/preflight.py --level full --check-dify
```

The Local Agent Lab remains the classroom failover if Dify is unavailable.
