<!-- mode=offline; sources=["/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/premarket_20251103_market.csv", "/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/premarket_20251103_portfolio.csv"] -->
# Premarket Agent - 离线确定性摘要

数据模式：合成 fixture（仅软件测试，不是真实2025市场证据）

当前未调用大模型。以下内容只确认文件存在与确定性程序输出，不提供投资结论。

## 输入文件
- market: premarket_20251103_market.csv (存在)
- portfolio: premarket_20251103_portfolio.csv (存在)

## 结论
输入已准备。需配置 LLM_API_KEY 才能生成自然语言盘前研究报告。