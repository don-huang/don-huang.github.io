<!-- mode=offline; sources=["/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/reports/preflight_latest.md", "/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/data/raw/tushare/snapshot_2025/manifest.json"] -->
# Data Quality Agent - 离线确定性摘要

数据模式：合成 fixture（仅软件测试，不是真实2025市场证据）

当前未调用大模型。以下内容只确认文件存在与确定性程序输出，不提供投资结论。

## 输入文件
- preflight: preflight_latest.md (存在)
- manifest: manifest.json (缺失)

## 结论
请先运行 scripts/preflight.py；其报告是数据质量 Agent 的确定性底稿。