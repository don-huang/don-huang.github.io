<!-- mode=offline; sources=["/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/agent_inputs/backtest_metrics.csv", "/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/agent_inputs/backtest_last_30_days.csv", "/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/simulated_trade_log_2025.csv"] -->
# Postmarket Agent - 离线确定性摘要

数据模式：合成 fixture（仅软件测试，不是真实2025市场证据）

当前未调用大模型。以下内容只确认文件存在与确定性程序输出，不提供投资结论。

## 输入文件
- metrics: backtest_metrics.csv (存在)
- last_30_days: backtest_last_30_days.csv (存在)
- trade_log: simulated_trade_log_2025.csv (存在)

## 结论
收益与成本由回测程序计算；需配置 LLM_API_KEY 才能生成行为复盘。