<!-- mode=offline; sources=["/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/agent_inputs/strategy_spec.md", "/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/agent_inputs/backtest_metrics.csv", "/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/agent_inputs/rebalance_log.csv"] -->
# Backtest Auditor - 离线确定性摘要

数据模式：合成 fixture（仅软件测试，不是真实2025市场证据）

当前未调用大模型。以下内容只确认文件存在与确定性程序输出，不提供投资结论。

## 输入文件
- strategy: strategy_spec.md (存在)
- metrics: backtest_metrics.csv (存在)
- rebalances: rebalance_log.csv (存在)

## 回测指标表
| series          |   observations |   total_return |   annualized_return |   annualized_volatility |   sharpe_rf0 |   max_drawdown |   positive_day_rate |   average_daily_turnover |   total_one_way_turnover |
|:----------------|---------------:|---------------:|--------------------:|------------------------:|-------------:|---------------:|--------------------:|-------------------------:|-------------------------:|
| strategy_gross  |            261 |      0.188298  |         0.18125     |                0.105814 |   1.71291    |     -0.046318  |            0.501916 |               0.00804598 |                      2.1 |
| strategy_net    |            261 |      0.184558  |         0.17766     |                0.105859 |   1.67827    |     -0.0466052 |            0.501916 |               0.00804598 |                      2.1 |
| benchmark_hs300 |            261 |     -0.0002817 |        -0.000271987 |                0.139735 |  -0.00194645 |     -0.13356   |            0.524904 |             nan          |                    nan   |