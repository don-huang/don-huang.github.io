<!-- mode=offline; sources=["/mnt/data/AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC/classroom_cache/snapshots/fixture_demo/processed/agent_inputs/factor_snapshot_latest.csv"] -->
# Factor Agent - 离线确定性摘要

数据模式：合成 fixture（仅软件测试，不是真实2025市场证据）

当前未调用大模型。以下内容只确认文件存在与确定性程序输出，不提供投资结论。

## 输入文件
- factor: factor_snapshot_latest.csv (存在)

## 确定性统计
- 行数：20
- Eligible：20
- Selected：5