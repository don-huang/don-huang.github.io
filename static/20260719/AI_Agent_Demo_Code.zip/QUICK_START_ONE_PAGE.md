# Instructor One-Page Quick Start

## External items you must obtain

1. **Tushare Pro account, token, and endpoint permissions** for `stock_basic`, `trade_cal`, `daily`, `adj_factor`, `daily_basic`, `fina_indicator`, and `index_daily`.
2. **Optional: one OpenAI-compatible LLM API key** for live Agent reports. Without it, the built-in Local Agent Lab uses deterministic offline reports. The package contains an example OpenAI-compatible configuration. Replace the base URL and model name with values that pass `python scripts/test_llm.py` before class.
3. Internet access for the first Tushare download. Live LLM mode also requires network access.

Dify is optional. The built-in Local Agent Lab completes all required Agent demos.

## Mac setup

```bash
unzip AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC.zip
cd AI_Agent_Demo_China_Tushare_Ashare_2025_v9_Growth_IC
bash scripts/bootstrap_mac.sh
```

Edit `.env`:

```text
TUSHARE_TOKEN=...
LLM_API_KEY=...  # optional; leave blank for offline Agent reports
LLM_BASE_URL=https://api.deepseek.com
LLM_MODEL=deepseek-v4-flash
```


## v8 users: mandatory data refresh

Growth requires additional `fina_indicator` fields. Run the first v9 setup without `--skip-download` and use a new cache ID, for example:

```bash
python instructor_setup.py --cache-id real_2025_course_v9_growth
```

Do not label an old v8 cache as a v9 five-factor result.

## First real run

```bash
python instructor_setup.py
```

The wizard will:

- test the environment;
- verify Tushare access;
- download 2024-2025 raw data;
- build the point-in-time five-factor dataset with Growth 35%, Quality 25%, Momentum 20%, Low Volatility 12% and Value 8%;
- run the 2025 backtest;
- create the separate Moutai/Wuliangye historical comparison and the Factor/Premarket/Postmarket/Backtest workflow inputs;
- freeze a classroom cache;
- generate live or offline Agent reports, including the strategy-level Investment Committee;
- run the full preflight.

## Launch the classroom application

```bash
bash scripts/run_local_agent_lab.sh
```

Open:

```text
http://127.0.0.1:8501
```

## Final go/no-go test

```bash
python scripts/preflight.py --level full
```

Proceed only when the report ends with `READY`.

## Offline software test only

```bash
python instructor_setup.py --fixture --offline-agents
```

The fixture has synthetic values. Never present its performance as real 2025 market evidence.


## Dependency recovery

The normal bootstrap uses `requirements_core.txt`. If a future dependency release causes a conflict, create a fresh environment and install the exact validation set:

```bash
python -m pip install -r requirements_tested_lock.txt
```
