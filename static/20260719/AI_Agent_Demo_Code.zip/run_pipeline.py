from __future__ import annotations

import argparse
from pathlib import Path

from src.backtest import run_backtest
from src.common import project_paths, setup_logging
from src.dataset import build_processed_dataset
from src.export_agent_inputs import export_agent_inputs
from src.features import build_factor_panel


def main() -> None:
    parser = argparse.ArgumentParser(description="Tushare A-share 2025 teaching pipeline")
    parser.add_argument(
        "stage",
        choices=["download", "process", "features", "backtest", "case", "workflows", "export", "cache", "agents", "classroom", "all"],
        help="Pipeline stage to run",
    )
    parser.add_argument("--root", default=None, help="Project root; defaults to this package")
    parser.add_argument("--cache-id", default=None, help="Classroom cache ID for cache/classroom stages")
    parser.add_argument("--allow-fixture", action="store_true", help="Allow synthetic fixture cache for software tests only")
    parser.add_argument("--offline-agents", action="store_true", help="Generate deterministic Agent reports")
    args = parser.parse_args()
    root = Path(args.root).resolve() if args.root else project_paths().root
    setup_logging(root)

    if args.stage in {"download", "all"}:
        from src.tushare_provider import TushareProvider
        summary = TushareProvider(root).download_all()
        print(summary.to_string(index=False))
    if args.stage in {"process", "classroom", "all"}:
        print(build_processed_dataset(root))
    if args.stage in {"features", "classroom", "all"}:
        panel = build_factor_panel(root)
        print(panel.groupby("signal_date")["selected"].sum())
    if args.stage in {"backtest", "classroom", "all"}:
        _, metrics, _ = run_backtest(root)
        print(metrics.to_string(index=False))
    if args.stage in {"case", "classroom", "all"}:
        from src.case_study import build_moutai_wuliangye_case
        print(build_moutai_wuliangye_case(root))
    if args.stage in {"workflows", "classroom", "all"}:
        from src.historical_workflows import build_historical_premarket_snapshot, build_simulated_trade_log
        print(build_historical_premarket_snapshot(root))
        print(build_simulated_trade_log(root))
    if args.stage in {"export", "classroom", "all"}:
        for path in export_agent_inputs(root):
            print(path)

    cache_path = None
    if args.stage in {"cache", "classroom"}:
        from src.cache_manager import prepare_classroom_cache
        cache_path = prepare_classroom_cache(root, cache_id=args.cache_id, allow_fixture=args.allow_fixture)
        print(cache_path)
    if args.stage in {"agents", "classroom"}:
        import os
        from src.agent_workflows import cache_agent_reports
        if cache_path is not None:
            os.environ["CLASSROOM_CACHE_ID"] = cache_path.name
        elif args.cache_id:
            os.environ["CLASSROOM_CACHE_ID"] = args.cache_id
        print(cache_agent_reports(root, force_offline=args.offline_agents))
        if cache_path is not None:
            from src.cache_manager import refresh_cache_manifest
            print(refresh_cache_manifest(cache_path))


if __name__ == "__main__":
    main()
