# Data License, Classroom Distribution, and Investment Boundary

## Tushare Pro data

This package contains downloader code and schemas, not paid Tushare raw market data.

The Instructor is responsible for:

1. using a valid licensed account and token;
2. confirming endpoint permissions;
3. complying with personal, educational, institutional and redistribution terms;
4. avoiding redistribution of raw licensed data unless authorized;
5. protecting account credentials.

## Recommended classroom distribution

- Instructor downloads and validates the data.
- Instructor freezes a dated classroom cache.
- The default cache excludes raw licensed files and contains derived outputs.
- Learners do not receive the Instructor token.
- Where distribution rights are unclear, learners use their own Tushare accounts.

## Synthetic fixture

`data/fixtures/` and `classroom_cache/snapshots/fixture_demo/` use synthetic numerical values in Tushare-compatible schemas. They are only for software tests and fallback workflow demonstrations.

They must not be described as real 2025 market data or performance.

## Privacy and security

- Do not upload client holdings, identity data or brokerage credentials.
- Do not expose `.env` or API keys.
- The Local Agent Lab binds to localhost by default.
- Do not expose the Streamlit port to the public internet.

## Investment boundary

The examples are educational. They are not investment advice, a recommendation, an offer, a solicitation or a guarantee of return. Backtests are historical validation tools and do not prove future performance. The package does not place live orders or connect to a brokerage account.
