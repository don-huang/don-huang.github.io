# Tushare Token and Permission Setup

## 1. Register and obtain the token

Create a Tushare Pro account, open the profile/token page and copy the Pro API token.

## 2. Confirm endpoint access

The core package requires:

- `stock_basic`
- `trade_cal`
- `daily`
- `adj_factor`
- `daily_basic`
- `fina_indicator`
- `index_daily`

`disclosure_date`, `income`, `balancesheet` and `cashflow` are optional.

A successful `stock_basic` call does not prove that the other endpoints are enabled.

## 3. Configure the package

```bash
cp .env.example .env
```

Edit `.env`:

```text
TUSHARE_TOKEN=your_actual_token
```

Never place the token in a Notebook cell or Prompt.

## 4. Check the token and permissions

```bash
python scripts/preflight.py --level credentials
python scripts/preflight.py --level data
```

The credentials check uses a small `stock_basic` request. The data check calls all required endpoints with small historical requests.

## 5. Run the real download

```bash
python run_pipeline.py download
```

Raw files and `manifest.json` are saved under:

```text
data/raw/tushare/snapshot_2025/
```

## 6. Troubleshooting

- `Token missing`: edit `.env` and restart the Kernel.
- `daily_basic` or `fina_indicator` permission error: verify points or subscription.
- empty ticker data: confirm code and date range.
- rate-limit error: increase `api.request_interval_seconds` in `config/course_config.yaml`.
- intermittent failure: rerun the download; the adapter has exponential retry.

## Security

- `.env` is excluded by `.gitignore`.
- `preflight.py` scans for configured secrets outside `.env`.
- use a teaching-specific token when possible;
- rotate the token if it appears on screen.
