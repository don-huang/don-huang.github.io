The packaged preflight_latest report was generated against the synthetic fixture cache.
Run the preflight commands again after configuring real Tushare data.
