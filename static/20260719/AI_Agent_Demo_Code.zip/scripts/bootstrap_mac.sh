#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

PYTHON=""

# On Apple Silicon, prefer the native Homebrew prefix over /usr/local Rosetta Python.
if [[ "$(uname -m)" == "arm64" ]]; then
  for candidate in \
    /opt/homebrew/opt/python@3.12/bin/python3.12 \
    /opt/homebrew/bin/python3.12 \
    /opt/homebrew/opt/python@3.11/bin/python3.11 \
    /opt/homebrew/bin/python3.11; do
    if [[ -x "$candidate" ]]; then
      PYTHON="$candidate"
      break
    fi
  done
fi

if [[ -z "$PYTHON" ]]; then
  for candidate in python3.12 python3.11; do
    if command -v "$candidate" >/dev/null 2>&1; then
      PYTHON="$(command -v "$candidate")"
      break
    fi
  done
fi

if [[ -z "$PYTHON" ]]; then
  echo "Python 3.11 or 3.12 was not found. Install it first, for example: brew install python@3.12" >&2
  exit 2
fi

if [[ "$(uname -m)" == "arm64" ]]; then
  PY_ARCH="$($PYTHON -c 'import platform; print(platform.machine())')"
  if [[ "$PY_ARCH" != "arm64" ]]; then
    echo "Selected Python is $PY_ARCH, but this is an Apple Silicon Mac." >&2
    echo "Install/use native ARM64 Python under /opt/homebrew before continuing." >&2
    exit 2
  fi
fi

"$PYTHON" -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements_core.txt
python -m ipykernel install --user \
  --name tushare-ashare-2025-v9 \
  --display-name "Python (Tushare A-share 2025 v9)"
[[ -f .env ]] || cp .env.example .env
python scripts/preflight.py --level offline
cat <<'MSG'

Bootstrap complete.
Next:
1. Edit .env and set TUSHARE_TOKEN and optional LLM_API_KEY.
2. Run a fresh v9 data build (do not reuse a v8 factor cache):
   python instructor_setup.py --cache-id real_2025_course_v9_growth
MSG
