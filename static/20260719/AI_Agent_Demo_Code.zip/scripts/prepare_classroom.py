from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.agent_workflows import cache_agent_reports
from src.cache_manager import prepare_classroom_cache, refresh_cache_manifest, verify_cache


def run(cmd: list[str]) -> None:
    print("+", " ".join(cmd))
    subprocess.run(cmd, cwd=ROOT, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build and freeze a classroom-ready snapshot")
    parser.add_argument("--skip-download", action="store_true", help="Use an already-downloaded raw snapshot")
    parser.add_argument("--include-raw", action="store_true", help="Include licensed raw data in the local cache")
    parser.add_argument("--allow-fixture", action="store_true", help="Software test only; cache will be marked synthetic")
    parser.add_argument("--offline-agent-reports", action="store_true", help="Do not call the LLM; create deterministic reports")
    parser.add_argument("--cache-id", default="real_2025_course", help="Portable classroom cache ID")
    parser.add_argument("--skip-build", action="store_true", help="Reuse existing processed outputs and only freeze/cache/report")
    args = parser.parse_args()

    run([sys.executable, "scripts/preflight.py", "--level", "offline"])
    if not args.skip_build:
        if not args.skip_download:
            run([sys.executable, "run_pipeline.py", "download"])
        for stage in ["process", "features", "backtest", "case", "workflows", "export"]:
            run([sys.executable, "run_pipeline.py", stage])

    snapshot = prepare_classroom_cache(
        ROOT,
        include_raw=args.include_raw,
        allow_fixture=args.allow_fixture,
        cache_id=args.cache_id,
    )
    print("Prepared cache:", snapshot)
    os.environ["CLASSROOM_CACHE_ID"] = snapshot.name
    cache_agent_reports(ROOT, force_offline=args.offline_agent_reports)
    refresh_cache_manifest(snapshot)

    issues = verify_cache(snapshot)
    if issues:
        raise RuntimeError("Cache verification failed:\n- " + "\n- ".join(issues))
    preflight_cmd = [sys.executable, "scripts/preflight.py", "--level", "full", "--cache-id", snapshot.name]
    if args.allow_fixture:
        preflight_cmd.append("--allow-fixture")
    run(preflight_cmd)
    print("Classroom preparation complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
