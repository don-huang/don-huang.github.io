from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.agent_workflows import cache_agent_reports

parser = argparse.ArgumentParser()
parser.add_argument("--offline", action="store_true")
parser.add_argument("--cache-id", default=None)
args = parser.parse_args()
if args.cache_id:
    os.environ["CLASSROOM_CACHE_ID"] = args.cache_id
out = cache_agent_reports(ROOT, force_offline=args.offline)
print(out)
