$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$python = $null
foreach ($candidate in @("py -3.12", "py -3.11", "python")) {
    try {
        Invoke-Expression "$candidate --version" | Out-Null
        $python = $candidate
        break
    } catch {}
}
if (-not $python) { throw "Python 3.11 or 3.12 is required." }
Invoke-Expression "$python -m venv .venv"
& .\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements_core.txt
python -m ipykernel install --user --name tushare-ashare-2025-v9 --display-name "Python (Tushare A-share 2025 v9)"
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
python scripts\preflight.py --level offline
Write-Host "Bootstrap complete. Edit .env, then run: python instructor_setup.py --cache-id real_2025_course_v9_growth"
