from __future__ import annotations

from pathlib import Path
import shutil

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "fixtures" / "tushare_schema_fixture"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2025)
universe = pd.read_csv(ROOT / "data" / "00_universe_ashare_2025.csv", dtype=str)
tickers = universe["ts_code"].tolist()
dates = pd.bdate_range("2024-01-02", "2025-12-31")

# The fixture has real tickers but synthetic numbers. It is only for installation testing.
price_frames, adj_frames, basic_frames = [], [], []
for i, ticker in enumerate(tickers):
    drift = 0.00015 + i * 0.00001
    vol = 0.012 + (i % 5) * 0.002
    returns = rng.normal(drift, vol, len(dates))
    close = (20 + i * 8) * np.exp(np.cumsum(returns))
    pre_close = np.r_[close[0], close[:-1]]
    daily = pd.DataFrame({
        "ts_code": ticker,
        "trade_date": dates.strftime("%Y%m%d"),
        "open": close * (1 + rng.normal(0, 0.002, len(dates))),
        "high": close * (1 + np.abs(rng.normal(0.004, 0.002, len(dates)))),
        "low": close * (1 - np.abs(rng.normal(0.004, 0.002, len(dates)))),
        "close": close,
        "pre_close": pre_close,
        "change": close - pre_close,
        "pct_chg": (close / pre_close - 1) * 100,
        "vol": rng.uniform(100_000, 5_000_000, len(dates)),
        "amount": rng.uniform(150_000, 2_000_000, len(dates)),
    })
    price_frames.append(daily)
    adj_frames.append(pd.DataFrame({"ts_code": ticker, "trade_date": dates.strftime("%Y%m%d"), "adj_factor": 1.0 + i * 0.01}))
    basic_frames.append(pd.DataFrame({
        "ts_code": ticker,
        "trade_date": dates.strftime("%Y%m%d"),
        "close": close,
        "turnover_rate": rng.uniform(0.2, 4.0, len(dates)),
        "turnover_rate_f": rng.uniform(0.2, 5.0, len(dates)),
        "volume_ratio": rng.uniform(0.5, 2.0, len(dates)),
        "pe": rng.uniform(8, 45, len(dates)),
        "pe_ttm": rng.uniform(8, 45, len(dates)),
        "pb": rng.uniform(0.8, 7.0, len(dates)),
        "ps_ttm": rng.uniform(0.8, 12.0, len(dates)),
        "dv_ttm": rng.uniform(0, 5, len(dates)),
        "total_share": rng.uniform(100_000, 5_000_000, len(dates)),
        "float_share": rng.uniform(80_000, 4_000_000, len(dates)),
        "free_share": rng.uniform(50_000, 3_000_000, len(dates)),
        "total_mv": rng.uniform(5_000_000, 250_000_000, len(dates)),
        "circ_mv": rng.uniform(4_000_000, 200_000_000, len(dates)),
    }))

pd.concat(price_frames, ignore_index=True).to_csv(OUT / "daily.csv", index=False)
pd.concat(adj_frames, ignore_index=True).to_csv(OUT / "adj_factor.csv", index=False)
pd.concat(basic_frames, ignore_index=True).to_csv(OUT / "daily_basic.csv", index=False)

financial_rows = []
for i, ticker in enumerate(tickers):
    for end_date, ann_date in [("20231231", "20240420"), ("20240630", "20240825"), ("20240930", "20241028"), ("20241231", "20250420"), ("20250630", "20250825"), ("20250930", "20251028")]:
        financial_rows.append({
            "ts_code": ticker,
            "ann_date": ann_date,
            "end_date": end_date,
            "roe": 6 + (i % 8) * 2 + rng.normal(0, 1),
            "roe_dt": 5 + (i % 8) * 2 + rng.normal(0, 1),
            "roa": 3 + (i % 7) + rng.normal(0, 0.5),
            "roic": 4 + (i % 7) + rng.normal(0, 0.5),
            "ocf_to_or": 0.05 + (i % 6) * 0.03 + rng.normal(0, 0.01),
            "debt_to_assets": 25 + (i % 7) * 8 + rng.normal(0, 2),
            "netprofit_margin": 5 + (i % 8) * 3 + rng.normal(0, 1),
            "grossprofit_margin": 15 + (i % 7) * 5 + rng.normal(0, 1),
            "profit_dedt": rng.uniform(100_000_000, 20_000_000_000),
            # Growth fields mirror stable Tushare fina_indicator names. Values are synthetic.
            "tr_yoy": -8 + (i % 9) * 4 + rng.normal(0, 3),
            "or_yoy": -7 + (i % 9) * 4 + rng.normal(0, 3),
            "netprofit_yoy": -12 + (i % 10) * 5 + rng.normal(0, 5),
            "dt_netprofit_yoy": -13 + (i % 10) * 5 + rng.normal(0, 5),
            "ocf_yoy": -20 + (i % 11) * 6 + rng.normal(0, 8),
        })
pd.DataFrame(financial_rows).to_csv(OUT / "fina_indicator.csv", index=False)

stock = universe.rename(columns={"name": "name_course"}).copy()
stock["symbol"] = stock["ts_code"].str[:6]
stock["name"] = stock["name_course"]
stock["industry"] = stock["industry_group"]
stock["market"] = "主板"
stock["list_status"] = "L"
stock["list_date"] = "20000101"
stock["delist_date"] = ""
stock[["ts_code","symbol","name","industry","market","exchange","list_status","list_date","delist_date"]].to_csv(OUT / "stock_basic.csv", index=False)

pd.DataFrame({"exchange": "SSE", "cal_date": dates.strftime("%Y%m%d"), "is_open": 1, "pretrade_date": dates.to_series().shift(1).dt.strftime("%Y%m%d").values}).to_csv(OUT / "trade_cal.csv", index=False)

benchmark_returns = rng.normal(0.0001, 0.009, len(dates))
bench_close = 4000 * np.exp(np.cumsum(benchmark_returns))
pd.DataFrame({
    "ts_code": "000300.SH",
    "trade_date": dates.strftime("%Y%m%d"),
    "open": bench_close,
    "high": bench_close * 1.005,
    "low": bench_close * 0.995,
    "close": bench_close,
    "pre_close": np.r_[bench_close[0], bench_close[:-1]],
    "change": np.r_[0, np.diff(bench_close)],
    "pct_chg": np.r_[0, np.diff(bench_close) / bench_close[:-1] * 100],
    "vol": rng.uniform(1e7, 5e8, len(dates)),
    "amount": rng.uniform(1e8, 5e9, len(dates)),
}).to_csv(OUT / "index_daily.csv", index=False)

for optional in ["disclosure_date", "income", "balancesheet", "cashflow"]:
    pd.DataFrame().to_csv(OUT / f"{optional}.csv", index=False)

(OUT / "README.txt").write_text(
    "SCHEMA TEST FIXTURE ONLY. Real A-share tickers, synthetic numerical values. Do not use in class as historical evidence.\n",
    encoding="utf-8",
)
print(OUT)
