from __future__ import annotations

import argparse
import importlib
import json
import os
import platform
import socket
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import pandas as pd
import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.cache_manager import detect_provenance, resolve_cache, validate_processed_outputs, verify_cache
from src.common import load_frame, project_paths
from src.llm_client import OpenAICompatibleClient, load_llm_settings


@dataclass
class Check:
    name: str
    status: str
    detail: str
    required: bool = True


class Preflight:
    def __init__(self, level: str, allow_fixture: bool = False, check_dify: bool = False, cache_id: str | None = None):
        self.level = level
        self.allow_fixture = allow_fixture
        self.check_dify = check_dify
        self.cache_id = cache_id
        self.paths = project_paths(ROOT)
        load_dotenv(ROOT / ".env", override=False)
        self.checks: list[Check] = []

    def add(self, name: str, ok: bool, detail: str, *, required: bool = True, warn: bool = False) -> None:
        status = "PASS" if ok else ("WARN" if warn or not required else "FAIL")
        self.checks.append(Check(name, status, detail, required))

    def run(self) -> list[Check]:
        self.check_environment()
        self.check_files()
        self.check_secret_hygiene()
        self.check_port()
        if self.level in {"credentials", "data", "full"}:
            self.check_tushare_token()
        if self.level in {"data", "full"}:
            self.check_raw_and_processed()
        if self.level == "full":
            self.check_llm()
            self.check_classroom_cache()
            if self.check_dify or os.getenv("DIFY_API_KEY", "").strip():
                self.check_dify_api()
        self.write_reports()
        return self.checks

    def check_environment(self) -> None:
        version = sys.version_info
        ok = version.major == 3 and 11 <= version.minor <= 13
        note = "recommended 3.11 or 3.12" if version.minor in {11, 12} else "3.13 accepted for the core package; 3.12 remains preferred"
        self.add(
            "Python version",
            ok,
            f"Detected {platform.python_version()}; {note}.",
        )
        modules = {
            "pandas": "pandas",
            "numpy": "numpy",
            "pyarrow": "pyarrow",
            "yaml": "PyYAML",
            "dotenv": "python-dotenv",
            "tenacity": "tenacity",
            "tushare": "tushare",
            "openai": "openai",
            "streamlit": "streamlit",
            "requests": "requests",
            "rich": "rich",
            "tabulate": "tabulate",
        }
        for module, package in modules.items():
            try:
                imported = importlib.import_module(module)
                version_text = getattr(imported, "__version__", "installed")
                self.add(f"Package {package}", True, str(version_text))
            except Exception as exc:
                self.add(f"Package {package}", False, str(exc))

    def check_files(self) -> None:
        required = [
            ROOT / "config" / "course_config.yaml",
            ROOT / "data" / "00_universe_ashare_2025.csv",
            ROOT / "run_pipeline.py",
            ROOT / "local_agent_lab" / "app.py",
            ROOT / "prompts" / "05_backtest_auditor_system.txt",
        ]
        for path in required:
            self.add(f"File {path.relative_to(ROOT)}", path.exists(), "present" if path.exists() else "missing")

    def check_secret_hygiene(self) -> None:
        env_path = ROOT / ".env"
        token = os.getenv("TUSHARE_TOKEN", "").strip()
        llm_key = os.getenv("LLM_API_KEY", "").strip() or os.getenv("DEEPSEEK_API_KEY", "").strip()
        excluded_parts = {".venv", ".git", "classroom_cache", "data", "logs", "reports", "__pycache__"}
        leaked: list[str] = []
        secrets = [value for value in [token, llm_key] if value and len(value) >= 12 and "replace_with" not in value]
        if secrets:
            for path in ROOT.rglob("*"):
                if not path.is_file() or path == env_path or any(part in excluded_parts for part in path.parts):
                    continue
                if path.suffix.lower() not in {".py", ".md", ".txt", ".yaml", ".yml", ".json", ".ipynb", ".sh", ".ps1", ".tex"}:
                    continue
                try:
                    content = path.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    continue
                if any(secret in content for secret in secrets):
                    leaked.append(str(path.relative_to(ROOT)))
        self.add("Secret hygiene", not leaked, "no configured secret found outside .env" if not leaked else ", ".join(leaked))

    def check_port(self) -> None:
        port = 8501
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            available = sock.connect_ex(("127.0.0.1", port)) != 0
        finally:
            sock.close()
        self.add("Streamlit port 8501", available, "available" if available else "already in use", required=False, warn=not available)

    def check_tushare_token(self) -> None:
        token = os.getenv("TUSHARE_TOKEN", "").strip()
        configured = bool(token and token != "replace_with_your_tushare_pro_token")

        if self.level == "credentials":
            self.add(
                "Tushare token configured",
                configured,
                "token present but not displayed" if configured else "missing or placeholder",
            )
            if configured:
                self.remote_endpoint_checks(token, minimal=False)
            return

        # Data/full checks are designed to work from a frozen local snapshot or cache.
        # A token is useful for refreshing data, but is not required to deliver an offline class.
        self.add(
            "Tushare token available for refresh",
            configured or self.allow_fixture,
            "token present but not displayed" if configured else "not configured; frozen data/cache will be used",
            required=False,
            warn=not configured,
        )

    def remote_endpoint_checks(self, token: str, minimal: bool) -> None:
        try:
            import tushare as ts
            ts.set_token(token)
            pro = ts.pro_api(token)
        except Exception as exc:
            self.add("Tushare client initialization", False, str(exc))
            return

        calls: list[tuple[str, Callable[[], pd.DataFrame], bool]] = [
            ("stock_basic", lambda: pro.stock_basic(exchange="", list_status="L", fields="ts_code,name,industry,list_date"), True),
        ]
        if not minimal:
            calls.extend([
                ("trade_cal", lambda: pro.trade_cal(exchange="SSE", start_date="20250102", end_date="20250110", fields="exchange,cal_date,is_open"), True),
                ("daily", lambda: pro.daily(ts_code="600519.SH", start_date="20250102", end_date="20250110", fields="ts_code,trade_date,close,amount"), True),
                ("adj_factor", lambda: pro.adj_factor(ts_code="600519.SH", start_date="20250102", end_date="20250110", fields="ts_code,trade_date,adj_factor"), True),
                ("daily_basic", lambda: pro.daily_basic(ts_code="600519.SH", start_date="20250102", end_date="20250110", fields="ts_code,trade_date,pe_ttm,pb,total_mv"), True),
                ("fina_indicator", lambda: pro.fina_indicator(ts_code="600519.SH", start_date="20240101", end_date="20251231", fields="ts_code,ann_date,end_date,tr_yoy,or_yoy,netprofit_yoy,dt_netprofit_yoy,ocf_yoy,roe,ocf_to_or,debt_to_assets"), True),
                ("index_daily", lambda: pro.index_daily(ts_code="000300.SH", start_date="20250102", end_date="20250110", fields="ts_code,trade_date,close"), True),
                ("disclosure_date", lambda: pro.disclosure_date(ts_code="600519.SH", start_date="20240101", end_date="20251231"), False),
            ])
        for name, func, required in calls:
            try:
                df = func()
                ok = isinstance(df, pd.DataFrame) and not df.empty
                self.add(f"Tushare endpoint {name}", ok, f"rows={len(df) if isinstance(df, pd.DataFrame) else 'N/A'}", required=required, warn=not required and not ok)
            except Exception as exc:
                self.add(f"Tushare endpoint {name}", False, str(exc), required=required, warn=not required)

    def check_raw_and_processed(self) -> None:
        provenance = detect_provenance(ROOT)
        eligible = provenance["classroom_eligible"] or self.allow_fixture
        self.add(
            "Raw data provenance",
            eligible,
            f"{provenance['kind']}: {provenance['message']}",
            warn=not provenance["classroom_eligible"] and self.allow_fixture,
        )
        raw = self.paths.raw / "snapshot_2025"
        for stem in ["daily", "adj_factor", "daily_basic", "fina_indicator", "index_daily", "trade_cal", "stock_basic"]:
            exists = (raw / f"{stem}.parquet").exists() or (raw / f"{stem}.csv").exists()
            self.add(f"Raw file {stem}", exists, "present" if exists else "missing")

        issues = validate_processed_outputs(ROOT)
        self.add("Processed output set", not issues, "complete" if not issues else "; ".join(issues))
        if issues:
            return
        try:
            factor = load_frame(self.paths.processed / "factor_panel_2025")
            factor["signal_date"] = pd.to_datetime(factor["signal_date"])
            selected = factor.groupby("signal_date")["selected"].sum()
            dates_ok = factor["signal_date"].min().year == 2025 and factor["signal_date"].max().year == 2025
            self.add("Factor signal dates", dates_ok, f"{factor['signal_date'].min().date()} to {factor['signal_date'].max().date()}")
            self.add("Selected names per month", bool((selected == 5).all()), selected.to_dict().__str__())
            if {"ann_date", "signal_date"}.issubset(factor.columns):
                ann = pd.to_datetime(factor["ann_date"], errors="coerce")
                sig = pd.to_datetime(factor["signal_date"], errors="coerce")
                self.add("Point-in-time ann_date", bool(((ann <= sig) | ann.isna()).all()), "all ann_date <= signal_date")
        except Exception as exc:
            self.add("Factor panel validation", False, str(exc))

        try:
            metrics = load_frame(self.paths.processed / "backtest_2025_metrics")
            required_series = {"strategy_gross", "strategy_net", "benchmark_hs300"}
            self.add("Backtest metrics series", required_series.issubset(set(metrics["series"])), ", ".join(metrics["series"].astype(str)))
            series = load_frame(self.paths.processed / "backtest_2025_timeseries")
            dates = pd.to_datetime(series["trade_date"])
            self.add("Backtest date coverage", dates.min().year == 2025 and dates.max().year == 2025, f"{dates.min().date()} to {dates.max().date()}")
        except Exception as exc:
            self.add("Backtest validation", False, str(exc))

    def check_llm(self) -> None:
        settings = load_llm_settings(ROOT)
        cache = resolve_cache(ROOT, self.cache_id)
        reports = cache / "agent_reports" if cache else None
        fallback_ok = bool(reports and reports.exists() and list(reports.glob("*.md")))

        if not settings.configured:
            self.add(
                "Live LLM configuration",
                fallback_ok,
                (f"not configured; using cached/offline reports at {reports}" if fallback_ok else "not configured and no cached reports"),
                required=not fallback_ok,
                warn=fallback_ok,
            )
            self.add("Cached Agent reports", fallback_ok, str(reports) if reports else "none", required=True)
            return

        self.add("Live LLM configuration", True, f"base={settings.base_url}; model={settings.model}; key hidden")
        try:
            response = OpenAICompatibleClient(settings).smoke_test()
            self.add("LLM API smoke test", bool(response.strip()), f"response={response[:80]!r}")
        except Exception as exc:
            # A frozen offline report set keeps the class runnable even if the live API is down.
            self.add(
                "LLM API smoke test",
                fallback_ok,
                f"live call failed: {exc}; offline fallback={'available' if fallback_ok else 'missing'}",
                required=not fallback_ok,
                warn=fallback_ok,
            )

    def check_classroom_cache(self) -> None:
        cache = resolve_cache(ROOT, self.cache_id)
        self.add("Classroom cache exists", cache is not None, str(cache) if cache else "missing")
        if cache:
            issues = verify_cache(cache)
            self.add("Classroom cache checksums", not issues, "valid" if not issues else "; ".join(issues))
            metadata_path = cache / "CACHE_METADATA.json"
            if metadata_path.exists():
                payload = json.loads(metadata_path.read_text(encoding="utf-8"))
                eligible = payload.get("provenance", {}).get("classroom_eligible", False)
                accepted_fixture = self.allow_fixture and not eligible
                self.add(
                    "Classroom cache provenance",
                    eligible or accepted_fixture,
                    payload.get("warning", "unknown"),
                    warn=accepted_fixture,
                )

    def check_dify_api(self) -> None:
        base = os.getenv("DIFY_BASE_URL", "").strip().rstrip("/")
        key = os.getenv("DIFY_API_KEY", "").strip()
        configured = bool(base and key)
        self.add("Dify API configuration", configured, f"base={base or 'missing'}; key hidden", required=False, warn=not configured)
        if not configured:
            return
        try:
            response = requests.get(f"{base}/info", headers={"Authorization": f"Bearer {key}"}, timeout=20)
            self.add("Dify API /info", response.ok, f"HTTP {response.status_code}: {response.text[:180]}", required=False, warn=not response.ok)
        except Exception as exc:
            self.add("Dify API /info", False, str(exc), required=False, warn=True)

    def write_reports(self) -> None:
        reports = ROOT / "reports"
        reports.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        payload = {
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "level": self.level,
            "checks": [asdict(item) for item in self.checks],
        }
        json_path = reports / f"preflight_{timestamp}.json"
        md_path = reports / f"preflight_{timestamp}.md"
        json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        lines = [f"# Instructor Preflight Report ({self.level})", "", f"Created: {payload['created_at_utc']}", "", "| Status | Check | Detail |", "|---|---|---|"]
        for item in self.checks:
            safe = item.detail.replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {item.status} | {item.name} | {safe} |")
        failures = [item for item in self.checks if item.status == "FAIL" and item.required]
        lines += ["", f"## Result: {'READY' if not failures else 'NOT READY'}", ""]
        md_path.write_text("\n".join(lines), encoding="utf-8")
        (reports / "preflight_latest.json").write_text(json_path.read_text(encoding="utf-8"), encoding="utf-8")
        (reports / "preflight_latest.md").write_text(md_path.read_text(encoding="utf-8"), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Instructor preflight checker")
    parser.add_argument("--level", choices=["offline", "credentials", "data", "full"], default="offline")
    parser.add_argument("--allow-fixture", action="store_true")
    parser.add_argument("--check-dify", action="store_true")
    parser.add_argument("--cache-id", default=None, help="Specific classroom cache ID to validate")
    args = parser.parse_args()
    checks = Preflight(args.level, args.allow_fixture, args.check_dify, args.cache_id).run()
    for item in checks:
        print(f"[{item.status}] {item.name}: {item.detail}")
    failures = [item for item in checks if item.status == "FAIL" and item.required]
    print("\nREADY" if not failures else "\nNOT READY")
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
