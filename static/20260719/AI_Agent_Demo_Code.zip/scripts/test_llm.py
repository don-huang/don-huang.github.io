from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.llm_client import OpenAICompatibleClient, load_llm_settings

settings = load_llm_settings(ROOT)
print("Base URL:", settings.base_url)
print("Model:", settings.model)
print("Key configured:", bool(settings.api_key))
print("Response:", OpenAICompatibleClient(settings).smoke_test())
