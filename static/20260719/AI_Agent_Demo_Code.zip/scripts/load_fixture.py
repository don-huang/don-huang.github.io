from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args: str) -> None:
    command = [sys.executable, *args]
    print('+', ' '.join(command))
    subprocess.run(command, cwd=ROOT, check=True)


def main() -> int:
    run('scripts/generate_fixture.py')
    fixture = ROOT / 'data' / 'fixtures' / 'tushare_schema_fixture'
    raw = ROOT / 'data' / 'raw' / 'tushare' / 'snapshot_2025'
    raw.mkdir(parents=True, exist_ok=True)

    # Remove a real-data manifest so provenance can never be mistaken after loading fixtures.
    (raw / 'manifest.json').unlink(missing_ok=True)
    for existing in raw.glob('*.csv'):
        existing.unlink()
    for existing in raw.glob('*.parquet'):
        existing.unlink()
    for path in fixture.glob('*.csv'):
        shutil.copy2(path, raw / path.name)
    (raw / 'README.txt').write_text(
        'SYNTHETIC FIXTURE DATA. Software test only. Not real 2025 market evidence.\n',
        encoding='utf-8',
    )

    for stage in ['process', 'features', 'backtest', 'case', 'workflows', 'export']:
        run('run_pipeline.py', stage)
    print('Fixture pipeline complete. This is NOT real market data.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
