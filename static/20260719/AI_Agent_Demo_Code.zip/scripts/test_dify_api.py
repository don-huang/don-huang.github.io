from __future__ import annotations

import os
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env", override=False)
base = os.getenv("DIFY_BASE_URL", "").strip().rstrip("/")
key = os.getenv("DIFY_API_KEY", "").strip()
if not base or not key:
    raise SystemExit("Set DIFY_BASE_URL and DIFY_API_KEY in .env first.")
response = requests.get(f"{base}/info", headers={"Authorization": f"Bearer {key}"}, timeout=20)
print("HTTP", response.status_code)
print(response.text)
response.raise_for_status()
