#!/usr/bin/env python3
"""
Generate data/00_universe_ashare_2025.csv from the latest available
CSI 300 constituent snapshot returned by Tushare Pro.

This intentionally uses a STATIC current universe for the entire 2025
backtest. It therefore has survivorship/look-ahead bias by design.

Output columns preserve the course package schema:
    ts_code,name,exchange,industry_group,teaching_role
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import tushare as ts
from dotenv import load_dotenv


INDEX_CODE_FALLBACKS = ("399300.SZ", "000300.SH")


def retry_call(func, *, attempts: int = 4, base_sleep: float = 2.0, label: str = "API"):
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return func()
        except Exception as exc:
            last_error = exc
            if attempt >= attempts:
                break
            wait = base_sleep * attempt
            print(
                f"[WARN] {label} failed ({attempt}/{attempts}): {exc}; "
                f"retrying in {wait:.1f}s",
                file=sys.stderr,
            )
            time.sleep(wait)
    assert last_error is not None
    raise RuntimeError(f"{label} failed after {attempts} attempts") from last_error


def normalize_exchange(ts_code: str, raw_exchange: str | None) -> str:
    if ts_code.endswith(".SH"):
        return "SSE"
    if ts_code.endswith(".SZ"):
        return "SZSE"
    if ts_code.endswith(".BJ"):
        return "BSE"

    mapping = {
        "SSE": "SSE",
        "SZSE": "SZSE",
        "BSE": "BSE",
        "SH": "SSE",
        "SZ": "SZSE",
        "BJ": "BSE",
    }
    return mapping.get(str(raw_exchange or "").upper(), str(raw_exchange or ""))


def backup_existing(path: Path) -> Path | None:
    if not path.exists():
        return None

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.stem}_backup_{stamp}{path.suffix}")
    shutil.copy2(path, backup)
    return backup


def fetch_latest_constituents(
    pro,
    *,
    lookback_days: int,
    index_codes: tuple[str, ...],
) -> tuple[pd.DataFrame, str, str]:
    end = date.today()
    start = end - timedelta(days=lookback_days)
    start_date = start.strftime("%Y%m%d")
    end_date = end.strftime("%Y%m%d")

    diagnostics: list[str] = []

    for index_code in index_codes:
        try:
            frame = retry_call(
                lambda: pro.index_weight(
                    index_code=index_code,
                    start_date=start_date,
                    end_date=end_date,
                ),
                label=f"index_weight {index_code}",
            )
        except Exception as exc:
            diagnostics.append(f"{index_code}: {exc}")
            continue

        if frame is None or frame.empty:
            diagnostics.append(f"{index_code}: empty result")
            continue

        required = {"index_code", "con_code", "trade_date", "weight"}
        missing = required.difference(frame.columns)
        if missing:
            diagnostics.append(
                f"{index_code}: missing columns {sorted(missing)}"
            )
            continue

        frame = frame.copy()
        frame["trade_date"] = frame["trade_date"].astype(str)
        snapshot_date = frame["trade_date"].max()
        latest = frame.loc[frame["trade_date"] == snapshot_date].copy()
        latest = latest.rename(columns={"con_code": "ts_code"})
        latest["ts_code"] = latest["ts_code"].astype(str)
        latest = latest.drop_duplicates("ts_code", keep="last")

        if latest["ts_code"].nunique() != 300:
            diagnostics.append(
                f"{index_code}: latest snapshot {snapshot_date} has "
                f"{latest['ts_code'].nunique()} unique constituents, expected 300"
            )
            continue

        return latest, index_code, snapshot_date

    raise RuntimeError(
        "Unable to obtain a complete 300-stock CSI 300 snapshot. "
        + " | ".join(diagnostics)
    )


def fetch_stock_basic(pro) -> pd.DataFrame:
    fields = (
        "ts_code,symbol,name,area,industry,market,exchange,"
        "list_status,list_date,delist_date"
    )
    frame = retry_call(
        lambda: pro.stock_basic(
            exchange="",
            list_status="L",
            fields=fields,
        ),
        label="stock_basic",
    )
    if frame is None or frame.empty:
        raise RuntimeError("stock_basic returned no rows")
    return frame.drop_duplicates("ts_code", keep="first")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Replace data/00_universe_ashare_2025.csv with the latest "
            "available static CSI 300 constituent list."
        )
    )
    parser.add_argument(
        "--project-root",
        default=".",
        help="v9 project root; default is the current directory.",
    )
    parser.add_argument(
        "--lookback-days",
        type=int,
        default=240,
        help=(
            "How far back to search for the latest index_weight snapshot. "
            "Default: 240 days."
        ),
    )
    parser.add_argument(
        "--index-code",
        action="append",
        dest="index_codes",
        help=(
            "Tushare index code; may be repeated. "
            "Default fallback: 399300.SZ then 000300.SH."
        ),
    )
    parser.add_argument(
        "--no-backup",
        action="store_true",
        help="Do not back up an existing universe CSV.",
    )
    args = parser.parse_args()

    root = Path(args.project_root).expanduser().resolve()
    data_dir = root / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    output_path = data_dir / "00_universe_ashare_2025.csv"
    manifest_path = data_dir / "00_universe_ashare_2025_manifest.json"

    load_dotenv(root / ".env")
    token = (os.getenv("TUSHARE_TOKEN") or "").strip()
    if not token:
        raise SystemExit(
            f"TUSHARE_TOKEN is missing from {root / '.env'}. "
            "The token will not be displayed."
        )

    index_codes = tuple(args.index_codes or INDEX_CODE_FALLBACKS)
    pro = ts.pro_api(token)

    print("Static current CSI 300 universe builder")
    print(f"Project root: {root}")
    print(f"Index-code fallback: {', '.join(index_codes)}")
    print("Token: configured (not displayed)")
    print()

    weights, used_index_code, snapshot_date = fetch_latest_constituents(
        pro,
        lookback_days=args.lookback_days,
        index_codes=index_codes,
    )
    stock_basic = fetch_stock_basic(pro)

    merged = weights.merge(
        stock_basic[
            ["ts_code", "name", "industry", "exchange", "list_status"]
        ],
        how="left",
        on="ts_code",
        validate="one_to_one",
    )

    missing_names = merged["name"].isna()
    if missing_names.any():
        missing_codes = merged.loc[missing_names, "ts_code"].tolist()
        raise RuntimeError(
            "Missing stock_basic metadata for constituent(s): "
            + ", ".join(missing_codes)
        )

    merged["exchange"] = [
        normalize_exchange(ts_code, exchange)
        for ts_code, exchange in zip(
            merged["ts_code"],
            merged["exchange"],
            strict=False,
        )
    ]
    merged["industry_group"] = merged["industry"].fillna("未分类")
    merged["teaching_role"] = (
        f"当前沪深300静态成分股（快照{snapshot_date}；"
        "用于2025全期；存在幸存者/前视偏差）"
    )

    universe = merged[
        ["ts_code", "name", "exchange", "industry_group", "teaching_role"]
    ].copy()
    universe = universe.sort_values("ts_code", kind="stable").reset_index(drop=True)

    if len(universe) != 300 or universe["ts_code"].nunique() != 300:
        raise RuntimeError(
            f"Final universe has {len(universe)} rows and "
            f"{universe['ts_code'].nunique()} unique tickers; expected 300."
        )

    backup = None
    if not args.no_backup:
        backup = backup_existing(output_path)
        if backup:
            print(f"Backed up existing file: {backup}")

    universe.to_csv(output_path, index=False, encoding="utf-8-sig")

    manifest = {
        "generated_at_local": datetime.now().astimezone().isoformat(),
        "provider": "Tushare Pro",
        "endpoint": "index_weight",
        "index_code": used_index_code,
        "snapshot_date": snapshot_date,
        "constituent_count": 300,
        "method": "latest available static CSI 300 constituent snapshot",
        "backtest_usage": "same current 300-stock universe used throughout 2025",
        "known_bias": (
            "survivorship/look-ahead bias intentionally accepted for this "
            "teaching demonstration"
        ),
        "output": str(output_path.relative_to(root)),
        "backup": (
            str(backup.relative_to(root))
            if backup is not None and backup.is_relative_to(root)
            else str(backup) if backup is not None else None
        ),
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print()
    print(f"[PASS] Latest snapshot date: {snapshot_date}")
    print(f"[PASS] Index code used: {used_index_code}")
    print(f"[PASS] Unique constituents: {universe['ts_code'].nunique()}")
    print(f"[PASS] Created: {output_path}")
    print(f"[PASS] Created: {manifest_path}")
    print()
    print(
        "Next step: rerun the download/pipeline because the universe has "
        "expanded from 20 to 300 stocks."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
