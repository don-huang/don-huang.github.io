#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -f .venv/bin/activate ]]; then
  source .venv/bin/activate
fi
exec streamlit run local_agent_lab/app.py --server.address 127.0.0.1 --server.port 8501
